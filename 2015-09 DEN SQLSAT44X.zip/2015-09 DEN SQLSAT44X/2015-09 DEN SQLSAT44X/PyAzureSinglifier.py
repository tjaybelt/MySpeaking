import codecs
import sys
import string

#azureFolders = ["F:/PyAzure/azure-0.10.0","F:/PyAzure/python-dateutil-2.4.2","F:/PyAzure/six-1.9.0"]
azureFolders = ["AzureModules.zip"]
#azureFolders = ["F:/PyAzure/AzureModules.zip"]
for folder in azureFolders:
	if folder not in sys.path:
		sys.path.insert(0, folder)

from azure.storage import BlobService

# expect arg 1 to be the storage account and arg 2 to be the key
assert len(sys.argv) == 3

blobSA = sys.argv[1]
blobSAKey = sys.argv[2]

blobService = BlobService(blobSA, blobSAKey)

for id in sys.stdin:
	id = id.strip()

	#sys.stderr.write("Attempting to open " + id + "\n")
	try:
		docBlob = blobService.get_blob_to_bytes("student", id)
		if docBlob[:3] == codecs.BOM_UTF8:
			docBlob = docBlob[3:]
		docLines = docBlob.replace("\t"," ").split("\r\n")
		docLines = [line.strip() for line in docLines]
		if len(docLines) > 0:
			print ' '.join(docLines)
		#else:
		#	print ''
		
	except:
		sys.stderr.write("Failed opening " + id + " : " + str(sys.exc_info()[0]) + "\n")
		#print ''
