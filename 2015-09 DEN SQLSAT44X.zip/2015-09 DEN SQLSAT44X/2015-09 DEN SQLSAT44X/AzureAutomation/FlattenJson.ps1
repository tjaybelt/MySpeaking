workflow FlattenJson
{
	Param
	(
		[string]$Environment = 'Prod'
	)

	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$credential = Get-AutomationPSCredential –Name 'SendGrid'
	$Creds = Get-AutomationPSCredential –Name 'automation'

	$StorageAccount = Get-AutomationVariable -Name ($Environment + "StorageAccount")
	$StorageKey = Get-AutomationVariable -Name ($Environment + "StorageKey")
	$StudentMongoTableProperties = MongoConnectionString -Environment $Environment -Database $nul -Collection "Student" -ReturnTableProperties $true

	$Acct = Add-AzureAccount -Credential $Creds
	"Successfully connected to Azure account {0}" -f $Acct.Id
	Set-AzureSubscription -SubscriptionName $SubscriptionName
	Select-AzureSubscription -SubscriptionName $SubscriptionName
	Use-AzureHDInsightCluster $ClusterName

	inlinescript
	{
		$Environment = $Using:Environment
		$MongoTable = "Student"
		$StorageAccount = $Using:StorageAccount
		$StorageKey = $Using:StorageKey

		$DocTable = $Environment + "Docs"
		$StudentTable = $Environment + "Student"
		$JSonLocation = "wasb://data@ilreportdata.blob.core.windows.net/StudentData/$DocTable";
		$PythonScript = "PyAzureSinglifier.py"
				
		$Query = " 
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
		add file wasb://includes@ilreportdata.blob.core.windows.net/$PythonScript;
		add file wasb://includes@ilreportdata.blob.core.windows.net/AzureModules.zip;
	   
		drop table if exists $DocTable;
		create external table $DocTable (json string)
		  row format delimited lines TERMINATED by '\n'
		  stored as textfile location '$JSonLocation';

		DROP TABLE IF EXISTS $StudentTable;
		CREATE EXTERNAL TABLE IF NOT EXISTS $StudentTable 
		(
		  id string,
		  firstlanguage string,
		  firstname string,
		  gradelevel int,
		  groups array<string>,
		  lastname string,
		  organizations array<string>,
		  password string,
		  sessiontime int,
		  studentnumber string,
		  username string,
		  writtenlanguage string,
		  archived boolean)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
			""id"":""_id"",
			""FirstLanguage"":""FirstLanguage"",
			""FirstName"":""FirstName"",
			""GradeLevel"":""GradeLevel"",
			""Groups"":""Groups"",
			""LastName"":""LastName"",
			""Organizations"":""Organizations"",
			""Password"":""Password"",
			""SessionTime"":""SessionTime"",
			""StudentNumber"":""StudentNumber"",
			""Username"":""Username"",
			""WrittenLanguage"":""WrittenLanguage"",
			""Archived"":""Archived""}') 
		$Using:StudentMongoTableProperties;
		
		insert overwrite table $DocTable
		  select transform (id)
			using 'python $PythonScript $StorageAccount $StorageKey' as (json)
			from $StudentTable
			where archived is null or archived = false;
		";
 
		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Preprocess $Environment Student Documents" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`nJob stdout:"
		Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardError
		}
	}
}
