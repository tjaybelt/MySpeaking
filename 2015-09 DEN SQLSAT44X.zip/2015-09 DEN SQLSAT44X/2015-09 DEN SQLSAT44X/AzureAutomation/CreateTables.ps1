workflow CreateTables
{
    
Param
	(
		[string]$Environment = 'Prod'
	)

	$ClusterName = Get-AutomationVariable –Name 'ClusterName'

	$StudentMongoTableProperties = MongoConnectionString -Environment $Environment -Database "" -Collection "Student" -ReturnTableProperties $true
	$StudentUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsage" -ReturnTableProperties $true
	$StudentUsageByDayMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsageByDay" -ReturnTableProperties $true
	$OrganizationMongoTableProperties = MongoConnectionString -Environment $Environment -Database "" -Collection "Organization" -ReturnTableProperties $true
	$OrganizationCountMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "OrganizationCount" -ReturnTableProperties $true
	$OrganizationUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "OrganizationUsage" -ReturnTableProperties $true
	$GroupMongoTableProperties = MongoConnectionString -Environment $Environment -Database "" -Collection "Group" -ReturnTableProperties $true
	$GroupCountMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "GroupCount" -ReturnTableProperties $true
	$GroupUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "GroupUsage" -ReturnTableProperties $true
	
	inlinescript
	{
		$Environment = $Using:Environment

		##FlattenJSon
		$DocTable = $Environment + "Docs"
		$JSonLocation = "wasb://data@ilreportdata.blob.core.windows.net/StudentData/$DocTable";
		$StudentTable = $Environment + "Student"

		##CreateStudentUsage
		#The location of the flattened json documents that contain student data
		$DocTable = $Environment + "Docs"
		$JSonLocation = "wasb://data@ilreportdata.blob.core.windows.net/StudentData/$DocTable";
		#Hive table that will pull out Activity Counted data about students
		$DocsActivityCounted = $Environment + "DocsActivityCounted";
		$StudentUsageH = $Environment + "StudentUsageHive";
		$StudentUsage = $Environment + "StudentUsage";
		$StudentUsageByDay = $Environment + "StudentUsageByDay";
		
		##CreateOrganizationUsage
		$OrganizationTable = $Environment + "Organization"
		$OrgsTable = $Environment + "Orgs"
		$StudentOrg = $Environment + "StudentOrg"
		$UniqueStudentOrg = $Environment + "UniqueStudentOrg"
		#$StudentUsage = $Environment + "StudentUsage2";
		$OrgUsageH = $Environment + "OrgUsageHive"
		$OrgCount = $Environment + "OrgCount"
		$OrgUsage = $Environment + "OrgUsage"

		##CreateGroupUsage		
		$GroupTable = $Environment + "Group"
		$StudentGroup = $Environment + "StudentGroup"
		$UniqueStudentGroup = $Environment + "UniqueStudentGroup"
		#$StudentUsage = $Environment + "StudentUsage2";
		$GroupCount = $Environment + "GroupCount"
		$GroupUsage = $Environment + "GroupUsage"

		#------------------------------------------------------
		
		$Query = " 
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;

		------FlattenJSon
		drop table if exists $DocTable;
		create external table $DocTable (json string)
		  row format delimited lines TERMINATED by '\n'
		  stored as textfile location '$JSonLocation';
		
		DROP TABLE IF EXISTS $StudentTable;
		CREATE EXTERNAL TABLE IF NOT EXISTS $StudentTable 
		(
		  id string,
		  FirstLanguage string,
		  FirstName string,
		  GradeLevel int,
		  Groups array<string>,
		  LastName string,
		  Organizations array<string>,
		  Password string,
		  SessionTime int,
		  StudentNumber string,
		  Username string,
		  WrittenLanguage string,
		  Archived boolean)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
			""id"":""_id"",
			""FirstLanguage"":""FirstLanguage"",
			""FirstName"":""FirstName"",
			""GradeLevel"":""GradeLevel"",
			""Groups"":""Groups"",
			""LastName"":""LastName"",
			""Organizations"":""Organizations"",
			""Password"":""Password"",
			""SessionTime"":""SessionTime"",
			""StudentNumber"":""StudentNumber"",
			""Username"":""Username"",
			""WrittenLanguage"":""WrittenLanguage"",
			""Archived"":""Archived""}') 
		$Using:StudentMongoTableProperties;
		
		
		------CreateStudentUsage		
		--This will be the HIVE table that points to the flattened student docs, and it will contain activity counted data for students		
		drop table if exists $DocsActivityCounted;
		CREATE EXTERNAL TABLE IF NOT EXISTS $DocsActivityCounted (
		  id string,
		  activitycountedcollection array<struct<datetime:string, elapsedseconds:double>>
		)
		ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
		WITH SERDEPROPERTIES ( ""mapping.id"" = ""_id"" )
		LOCATION '$JSonLocation';

		
		--This will create a HIVE table that has properties that make it a Mongo table. 
		drop table if exists $StudentUsageH;
		create external table $StudentUsageH
		(
		  studentid string, 
		  datetime date, 
		  elapsedseconds float
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentUsageH';
		  
		  
		--This will create a HIVE table that has properties that make it a Mongo table. 
		--It will contain StudentUsage with a sum of usage for Year and WeekOfYear 
		create table if not exists $StudentUsage
		(
		  studentid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds double		--float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table if exists $StudentUsage;

		--Then we need to create it again, so that it is empty and ready to be filled by the insertoverwrite, which only fills, not overwrites.
		create table if not exists $StudentUsage 
		(
		  studentid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;
		
		
		--This will create a HIVE table that has properties that make it a Mongo table. 
		--It will contain StudentUsage with a sum of usage for each day
		create table if not exists $StudentUsageByDay 
		(
		  studentid string, 
		  datetime date, 
		  elapsedseconds float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageByDayMongoTableProperties;

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table if exists $StudentUsageByDay;

		--Then we need to create it again, so that it is empty and ready to be filled by the insertoverwrite, which only fills, not overwrites.
		create table if not exists $StudentUsageByDay 
		(
		  studentid string, 
		  datetime date, 
		  elapsedseconds float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageByDayMongoTableProperties;
		  
			  		  

		------CreateOrganizationUsage
		DROP TABLE IF EXISTS $OrganizationTable;
		CREATE EXTERNAL TABLE $OrganizationTable 
		(
		  id string,
		  name string,
		  ancestors array<string>
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{""id"":""_id"",""name"",""Name"",""ancestors"":""Ancestors""}' )
		$Using:OrganizationMongoTableProperties;

		
		--OrgTree type table
		drop table if exists $OrgsTable;
		create external table $OrgsTable
		(
		  organizationid string,
		  childorganizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$OrgsTable';

		
		drop table if exists $StudentOrg;
		create external table $StudentOrg
		(
		  studentid string,
		  organizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$StudentOrg';
		
		
		--unique students that pertain to each organization
		--for each organization and level, collect all students, and then get usage by gathering distinct student usage
		drop table if exists $UniqueStudentOrg;
		create external table $UniqueStudentOrg
		(
		  studentid string,
		  organizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$UniqueStudentOrg';
		
		
--		--need to rename this table, so that we can point to it as a double, not a float, because data types are hard
--		drop table if exists $StudentUsage;
--		create external table if not exists $StudentUsage
--		(
--		  studentid string, 
--		  collectedyear int, 
--		  collectedweek int, 
--		  elapsedseconds double
--		)
--		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
--		$Using:StudentUsageMongoTableProperties;


		drop table if exists $OrgUsageH;
		create external table $OrgUsageH
		(
		  organizationid string, 
		  datetime date, 
		  elapsedseconds float
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$OrgUsageH';

		
		--number of active unique students in each organization
		--where active is currently defined as belonging to a group, though it may eventually be tied to licenses
		drop table if exists $OrgCount;
		create table $OrgCount
		(
			organizationid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationCountMongoTableProperties;
		-- drop and create a second time, because sometimes once just isn't enough
		drop table $OrgCount;
		create table $OrgCount
		(
			organizationid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationCountMongoTableProperties;


	--before and after counts are collected
		--Generate Students associated to Organizations
		--This will create a HIVE table that has properties that make it a Mongo table. 
		create table if not exists $OrgUsage
		(
		  organizationid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationUsageMongoTableProperties;


		------CreateGroupUsage
		--MongoDB Group data
		DROP TABLE IF EXISTS $GroupTable;
		CREATE EXTERNAL TABLE $GroupTable 
		(
          id string,
          name string,
          OrganizationId string
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
        with SERDEPROPERTIES( 'mongo.columns.mapping' = '{""id"":""_id"",""name"":""Name"",""OrganizationId"":""OrganizationId""}' )
		$Using:GroupMongoTableProperties;


		drop table if exists $StudentGroup;
		create external table $StudentGroup
		(
		  studentid string,
		  groupid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/GroupData/$StudentGroup';
		
		
		--unique students that pertain to each group
		--for each group, collect all students, and then get usage by gathering distinct student usage
		drop table if exists $UniqueStudentGroup;
		create external table $UniqueStudentGroup
		(
		  studentid string,
		  groupid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/GroupData/$UniqueStudentGroup';
		

--		--need to rename this table, so that we can point to it as a double, not a float, because data types are hard
--		drop table if exists $StudentUsage;
--		create external table if not exists $StudentUsage
--		(
--		  studentid string, 
--		  collectedyear int, 
--		  collectedweek int, 
--		  elapsedseconds double
--		)
--		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
--		$Using:StudentUsageMongoTableProperties;


		--number of active unique students in each group
		--where active is currently defined as belonging to a group, though it may eventually be tied to licenses
		drop table if exists $GroupCount;
		create table $GroupCount
		(
			groupid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupCountMongoTableProperties;
		-- drop and create a second time, because sometimes once just isn't enough
		drop table $GroupCount;
		create table $GroupCount
		(
			groupid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupCountMongoTableProperties;


	-- before and after counts are collected
		--Generate Students associated to Groups
		--This will create a HIVE table that has properties that make it a Mongo table. 
		create table if not exists $GroupUsage
		(
		  groupid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupUsageMongoTableProperties;
		";

$Query;

<#
		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Create Tables" -RunAsFile
		
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`nJob stdout:"
		
		Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) 
		{
			"Job failed!"
			"`nJob stderr:"
			Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardError
		}
#>

	}
    
}