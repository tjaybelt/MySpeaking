workflow Collect-BuildsInField
{
   
    $Credential = Get-AutomationPSCredential –Name 'automation'
    $SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName'
    $ClusterName = Get-AutomationVariable –Name 'ClusterName'
    $Acct = Add-AzureAccount -Credential $Credential
	"Successfully connected to Azure account {0}" -f $Acct.Id
    Set-AzureSubscription -SubscriptionName $SubscriptionName
    Select-AzureSubscription -SubscriptionName $SubscriptionName 
    Use-AzureHDInsightCluster $ClusterName

    inlinescript
    {
        $Environment = 'Prod'

        $OrganizationTable = $Environment + "Organization"
    	$CloudAdoption = $Environment + "CloudAdoption"
        $OrgsTable = $Environment + "Orgs"

        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;


        drop table if exists $CloudAdoption;
        create table $CloudAdoption
        (
          type string,
	      environment string,
          datetime timestamp,
          count int
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$CloudAdoption';
        drop table if exists $CloudAdoption;

        drop table if exists $CloudAdoption;
        create external table $CloudAdoption
        (
          type string,
	      environment string,
          count int
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$CloudAdoption';

	    insert into table $CloudAdoption
          select 
              case 
                when ot.organizationtype = 0 then 'Districts'
                when ot.organizationtype = 1 then 'Schools'
                when ot.organizationtype = 2 then 'Other'
              end,
              ""$Environment"",
              count(*) 
            from $OrgsTable o
            left outer join $OrganizationTable ot on ot.id = o.childorganizationid
            where o.organizationid = '00000000-0000-0000-0000-000000000004'
              and ot.SiteCode is not null
            group by ot.organizationtype
        ;
        ";

        #Invoke-hive -Query $Query;
#At Collect-BuildsInField:13 char:13

        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Collect Builds In Field" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob

    }

}