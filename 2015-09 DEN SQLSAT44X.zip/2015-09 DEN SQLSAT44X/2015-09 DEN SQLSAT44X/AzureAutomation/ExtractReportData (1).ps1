workflow ExtractReportData
{
	Param
	(
		[string]$Environment = ''
	)
	
	[string]$MailSubject = Get-AutomationVariable –Name 'Subject'
	[string]$MailFrom = Get-AutomationVariable –Name 'From'
	[string]$MailTo = Get-AutomationVariable –Name 'To'

	$Body = "
	################################################################
	#    Create cluster
	################################################################
	"
	$CreateClusterStartTime = Get-Date
	$sresult = CreateHDCluster
	$result = FlattenArrays -array $sresult
	$CreateClusterEndTime = Get-Date
	$CreateClusterDiff = ($CreateClusterEndTime - $CreateClusterStartTime).ToString("hh\:mm")
	$Body += "HDinsight Cluster Created.`n`nDiff $CreateClusterDiff`tStarted at $CreateClusterStartTime`tEnded at $CreateClusterEndTime.`n`n" + ($result -replace "`n","" -join "`n")
	"Results from CreateHDCluster:"
	$result
	SendMail -From $MailFrom -To $MailTo -Subject $MailSubject -Body $Body
	$oBody = $Body
	Checkpoint-Workflow


	if ($Environment -ne '')   #This will allow us to pass in a single environment that needs to be done
	{
	  $Environments = $Environment;
	}
	else
	{
	  $Environments = (Get-AzureAutomationVariable -AutomationAccountName 'Reports' -Name 'Environments').value.Split()
	}

	ForEach ($Environment in $Environments)
	{
		$OverallStartTime = Get-Date

		$Body = "
		################################################################
		#    FlattenJSon for $Environment
		################################################################
		"
		$FlattenStartTime = Get-Date
		$sresult = FlattenJson -Environment $Environment
		$result = FlattenArrays -array $sresult
		$FlattenEndTime = Get-Date
		$OverallFlattenDiff = ($FlattenEndTime - $FlattenStartTime).ToString("hh\:mm")
		$Body += "Diff $OverallFlattenDiff`tStarted at $FlattenStartTime`tEnded at $FlattenEndTime.`n`n" + ($result -replace "`n","" -join "`n") + "`n`n"
		"Results from FlattenJson for $Environment :"
		$result
		Checkpoint-Workflow


		$Body += "
		################################################################
		#    Usage for $Environment
		################################################################
		"
		$UsageStartTime = Get-Date
		$sresult = Create-Usage-Data -Environment $Environment
		$result = FlattenArrays -array $sresult
		$UsageEndTime = Get-Date
		$OverallUsageDiff = ($UsageEndTime - $UsageStartTime).ToString("hh\:mm")
		$Body += "Diff $OverallUsageDiff`tStarted at $UsageStartTime`tEnded at $UsageEndTime.`n`n" + ($result -replace "`n","" -join "`n") + "`n`n"
		"Results from Usage for $Environment :"
		$result
		Checkpoint-Workflow


		$Body += "
		################################################################
		#    Growth Map-Reduce for $Environment
		################################################################
		"
		$GrowthStartTime = Get-Date
		$sresult = GrowthMapReduce -Environment $Environment
		$result = FlattenArrays -array $sresult
		$GrowthEndTime = Get-Date
		$OverallGrowthDiff = ($GrowthEndTime - $GrowthStartTime).ToString("hh\:mm")
		$Body += "Diff $OverallGrowthDiff`tStarted at $GrowthStartTime`tEnded at $GrowthEndTime.`n`n" + ($result -replace "`n","" -join "`n") + "`n`n"
		"Results from Growth Map-Reduce for $Environment :"
		$result
		#SendMail -From $MailFrom -To $MailTo -Body $Body -Subject $MailSubject
		Checkpoint-Workflow


		$Body += "
		################################################################
		#    Progress Map-Reduce for $Environment
		################################################################
		"
		$ProgressStartTime = Get-Date
		$sresult = ProgressMapReduce -Environment $Environment
		$result = FlattenArrays -array $sresult
		$ProgressEndTime = Get-Date
		$OverallProgressDiff = ($ProgressEndTime - $ProgressStartTime).ToString("hh\:mm")
		$Body += "Diff $OverallProgressDiff`tStarted at $ProgressStartTime`tEnded at $ProgressEndTime.`n`n" + ($result -replace "`n","" -join "`n") + "`n`n"
		"Results from Progress Map-Reduce for $Environment :"
		$result
		#SendMail -From $MailFrom -To $MailTo -Body $Body -Subject $MailSubject
		Checkpoint-Workflow
	
   
		################################################################
		#    reporting / emailing / cachivachi
		################################################################
		$OverallEndTime = Get-Date
		$OverallDiff = ($OverallEndTime - $OverallStartTime).ToString("hh\:mm")
		$Body = "ETL Processed for $Environment`n`n" + 
				"Overall`n`tDiff $OverallDiff`tStarted at $OverallStartTime`tEnded at $OverallEndTime.`n`n" +
				"FlattenJson`n`tDiff $OverallFlattenDiff`tStarted at $FlattenStartTime`tEnded at $FlattenEndTime.`n`n" +
				"Usage`n`tDiff $OverallUsageDiff`tStarted at $UsageStartTime`tEnded at $UsageEndTime.`n`n" + 
				"Growth`n`tDiff $OverallGrowthDiff`tStarted at $GrowthStartTime`tEnded at $GrowthEndTime.`n`n" +
				"Progress`n`tDiff $OverallProgressDiff`tStarted at $ProgressStartTime`tEnded at $ProgressEndTime.`n`n" +
				"`n`n----------`n`n" + $Body + "`n----------`n`n"
		SendMail -From $MailFrom -To $MailTo -Body $Body -Subject $MailSubject
	
		$oBody += "`n`n################################################################`n################################################################`n`n" + $Body
	}

	$OverallEndTime = Get-Date
	$OverallDiff = ($OverallEndTime - $CreateClusterStartTime).ToString("hh\:mm")
	$Body = "Entire ETL Process, All tasks, All environments`n" +
			"Overall`n`tDiff $OverallDiff`tStarted at $CreateClusterStartTime`tEnded at $OverallEndTime.`n`n" +
			"`n`n----------`n`n" + $oBody + "`n----------`n`n"
	SendMail -From $MailFrom -To $MailTo -Body $Body -Subject $MailSubject
}
