workflow CreateGroupUsage
{

	Param
	(
		[string]$Environment = 'Prod'
	)
		
	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$credential = Get-AutomationPSCredential –Name 'SendGrid'
	$Creds = Get-AutomationPSCredential –Name 'automation'

	$Acct = Add-AzureAccount -Credential $Creds
	"Successfully connected to Azure account {0}" -f $Acct.Id
	Set-AzureSubscription -SubscriptionName $SubscriptionName
	Select-AzureSubscription -SubscriptionName $SubscriptionName
	Use-AzureHDInsightCluster $ClusterName

	$StudentUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsage" -ReturnTableProperties $true
	$GroupMongoTableProperties = MongoConnectionString -Environment $Environment -Database $nul -Collection "Group" -ReturnTableProperties $true
	$GroupUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "GroupUsage" -ReturnTableProperties $true
	$GroupCountMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "GroupCount" -ReturnTableProperties $true
	
	inlinescript
	{
		$Environment = $Using:Environment

		$StudentTable = $Environment + "Student"
		$GroupTable = $Environment + "Group"
		$GroupUsage = $Environment + "GroupUsage"
		$GroupCount = $Environment + "GroupCount"
		$StudentGroup = $Environment + "StudentGroup"
		$UniqueStudentGroup = $Environment + "UniqueStudentGroup"
		$StudentUsage = $Environment + "StudentUsage2";

		$Query = "
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;

		--MongoDB Group data
		DROP TABLE IF EXISTS $GroupTable;
		CREATE EXTERNAL TABLE $GroupTable 
		(
          id string,
          Name string,
          OrganizationId string
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
        with SERDEPROPERTIES( 'mongo.columns.mapping' = '{""id"":""_id"",""Name"":""Name"",""OrganizationId"":""OrganizationId""}' )
		$Using:GroupMongoTableProperties;


		
		--Generate Students Groups - because cant do a lateral view explosion and a join
		drop table if exists $StudentGroup;
		create external table $StudentGroup
		(
		  studentid string,
		  groupid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/GroupData/$StudentGroup';
		
		insert overwrite table $StudentGroup
		  select
			  id as studentid,
			  columnAlias as groupid
			from $StudentTable S
			LATERAL VIEW EXPLODE(S.Groups) tableAlias as columnAlias;



		--unique students that pertain to each group
		--for each group, collect all students, and then get usage by gathering distinct student usage
		drop table if exists $UniqueStudentGroup;
		create external table $UniqueStudentGroup
		(
		  studentid string,
		  groupid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/GroupData/$UniqueStudentGroup';
		
		insert overwrite table $UniqueStudentGroup
		  select distinct
			  sg.studentid,
			  g.id as groupid
			from $StudentGroup sg
			left outer join $GroupTable g on g.id = sg.groupid;


		--number of active unique students in each group
		--where active is currently defined as belonging to a group, though it may eventually be tied to licenses

		-- we want to clear out the existing GroupCount table in Mongo...
		-- if the Hadoop cluster is new we might not have an existing connection to the table,
		-- so create the connection (not external) then to clear it out drop it and recreate it 
		create table if not exists $GroupCount
		(
			groupid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupCountMongoTableProperties;
		drop table $GroupCount;
		create table $GroupCount
		(
			groupid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupCountMongoTableProperties;

		insert overwrite table $GroupCount
		  select
			groupid,
			count(*)
		  from $UniqueStudentGroup
		  group by groupid;

		--need to rename this table, so that we can point to it as a double, not a float, because data types are hard
		drop table if exists $StudentUsage;
		create external table if not exists $StudentUsage
		(
		  studentid string,
		  collectedyear int,
		  collectedweek int,
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;


   
		--Generate Students associated to Groups
		--This will create a HIVE table that has properties that make it a Mongo table. 
		create table if not exists $GroupUsage
		(
		  groupid string,
		  collectedyear int,
		  collectedweek int,
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupUsageMongoTableProperties;

		select '';
		select 'Before Count of $GroupUsage';
		select '-----------------------------';
		select count(*) from $GroupUsage;
		select '';

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table $GroupUsage;

		--Then we need to create it again, so that it is empty and ready to be filled.
		create table if not exists $GroupUsage
		(
		  groupid string,
		  collectedyear int,
		  collectedweek int,
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:GroupUsageMongoTableProperties;

		insert overwrite table $GroupUsage
		  select
			  sg.groupid,
			  su.collectedyear,
			  su.collectedweek,
			  sum(su.elapsedseconds) as elapsedseconds
			from $UniqueStudentGroup sg
			  join $StudentUsage su on su.studentid = sg.studentid
			group by
			  sg.groupid,
			  su.collectedyear,
			  su.collectedweek;

		select 'After Count of $GroupUsage';
		select '-----------------------------';
		select count(*) from $GroupUsage;
		select '';
		";

		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Process $Environment GroupUsage" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob -WaitTimeoutInSeconds 5500
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`n{0} {1}" -f $Environment, "GroupUsage"
		"`nJob stdout:"
		"--------------------------------------------------------------------------------------------" 
		Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			"--------------------------------------------------------------------------------------------" 
			Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardError
			"--------------------------------------------------------------------------------------------" 
		}
	}
}
