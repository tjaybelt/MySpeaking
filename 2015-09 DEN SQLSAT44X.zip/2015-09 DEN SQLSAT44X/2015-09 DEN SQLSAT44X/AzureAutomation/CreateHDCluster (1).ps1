workflow CreateHDCluster
{
    $HDcredential = Get-AutomationPSCredential –Name 'HDCluster'
    $Credential = Get-AutomationPSCredential –Name 'automation'

    $SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName'
    $StorageAccountName = Get-AutomationVariable –Name 'StorageAccountName'
    $ContainerName = Get-AutomationVariable –Name 'ContainerName'
    $ClusterName = Get-AutomationVariable –Name 'ClusterName'
    $Location = Get-AutomationVariable –Name 'Location'
    $ClusterNodes = Get-AutomationVariable –Name 'ClusterNodes'

    $Acct = Add-AzureAccount -Credential $Credential
	"Successfully connected to Azure account {0}" -f $Acct.Id
    Set-AzureSubscription -SubscriptionName $SubscriptionName
    Select-AzureSubscription -SubscriptionName $SubscriptionName 
  
    $key1 = (Get-AzureStorageKey $StorageAccountName).Primary

    inlinescript
    {
    	function QueryCluster ([string]$ClusterName, [int]$Retries = 5) {
    		for ($i = 1; $i -le $Retries; $i++) {
	    		try {
	    			$result = Use-AzureHDInsightCluster $ClusterName
			        $result = Invoke-Hive -Query "show tables;" -JobName "Check cluster health"
			        # may need to check hive job exist code
			        return $True
				}
				catch [system.exception] {
					if ($Retries -gt 1) {
						$attempt = ", {0}/{1}" -f $i, $Retries
					}
					Write-Warning ("Could not connect to or query HDInsight cluster {0}{1}" -f $ClusterName, $attempt)
					Start-Sleep -Seconds 60
				}
			}
			return $False
		}

        if (QueryCluster $Using:ClusterName -Retries 1) {
	    	"HDInsight cluster {0} is already up, skipping create" -f $Using:ClusterName
	        return
		}
		"HDInsight cluster {0} is not up, proceeding to create it" -f $Using:ClusterName

        for ($i=1; $i -le 5; $i++)
        {
            try
            {
                $cluster = New-AzureHDInsightClusterConfig -ClusterSizeInNodes $Using:ClusterNodes `
                    | Set-AzureHDInsightDefaultStorage -StorageAccountName "$Using:StorageAccountName.blob.core.windows.net" -StorageAccountKey $Using:key1 -StorageContainerName $Using:ContainerName `
                    | New-AzureHDInsightCluster -Name $Using:ClusterName -Location $Using:Location -Credential $Using:HDcredential
				"Successfully created HDInsight cluster {0} with {1} nodes in datacenter {2}" -f $cluster.Name, $cluster.ClusterSizeInNodes, $cluster.Location

				if (QueryCluster $Using:ClusterName) {
					"Successfully connected to and queried newly created HDInsight cluster {0}" -f $Using:ClusterName
	                return
				} else {
					"Failed to connect to and query newly created HDInsight cluster {0}, attempt #{1}/5" -f $Using:ClusterName, $i
				} 
            }
            Catch [system.exception]
            {
				"Failed to create HDInsight cluster {0}, attempt #{1}/5" -f $Using:ClusterName, $i
                Remove-AzureHDInsightCluster -Name $Using:ClusterName 
            }
        }
        "Failed to create and connect to HDInsight Cluster (after 5 tries)"
    }
}
