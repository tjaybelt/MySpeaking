workflow FlattenArrays
{
    Param ($array)

    inlinescript {
        Function FlattenArraysFn($arrayOfArrays) {
            ForEach ($element in $arrayOfArrays) {
                if ($element -is [System.Array]) {
                    FlattenArraysFn($element)
                } else {
                    $element
                }
            }
        }
        # easiest done with recursion,
        # since we can't recurse a workflow, use an inlinescript function to do all the work        
        FlattenArraysFn $Using:array
    }
}