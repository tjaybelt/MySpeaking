workflow DestroyHDCluster
{
    [string]$MailSubject = Get-AutomationVariable –Name 'Subject'
    [string]$MailFrom = Get-AutomationVariable –Name 'From'
    [string]$MailTo = Get-AutomationVariable –Name 'To'
    
    $SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
    $ClusterName = Get-AutomationVariable –Name 'ClusterName'
    $credential = Get-AutomationPSCredential –Name 'SendGrid'
    $Creds = Get-AutomationPSCredential –Name 'automation'

    $Acct = Add-AzureAccount -Credential $Creds
	"Successfully connected to Azure account {0}" -f $Acct.Id
    Set-AzureSubscription -SubscriptionName $SubscriptionName
    Select-AzureSubscription -SubscriptionName $SubscriptionName

    $Success = "Cluster shutdown succeeded."
    
    $result = inlinescript
    {               
      try
      {
        Use-AzureHDInsightCluster $Using:ClusterName
        $Connected = $true 
      }
      catch [System.Exception]
      {
        $Connected = $false
        "Unable to connect to cluster {0}, skipping destroy." -f $Using:ClusterName
      }

      if ($Connected -eq $true)
  	  {
        try
        {
          Remove-AzureHDInsightCluster -Name $Using:ClusterName
          $Using:Success
        }
        Catch [System.Exception]
        {
          "Unable to remove cluster {0}." -f $Using:ClusterName
        }
	  }		
    }
  
    if ($Success -in $result)
    {
        $Body = "HDinsight Cluster Destroyed."
    }
    else
    {
        $Body = "HDinsight Cluster not Destroyed, as it doesn't exist or couldn't be connected to."
    }

    $Body = $Body + "`n`n" + ($result -Join "`n`t") +
        "`n`nAzure Automation has processed the ETL of Student documents data via HDInsight"

	SendMail -From $MailFrom -To $MailTo -Subject $MailSubject -Body $Body

    $result
}
