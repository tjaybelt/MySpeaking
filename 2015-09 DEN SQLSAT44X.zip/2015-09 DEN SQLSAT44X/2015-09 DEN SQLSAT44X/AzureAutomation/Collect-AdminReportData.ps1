workflow Collect-AdminReportData
{
    $Credential = Get-AutomationPSCredential –Name 'automation'
    $SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName'
    $ClusterName = Get-AutomationVariable –Name 'ClusterName'
    $Acct = Add-AzureAccount -Credential $Credential
	"Successfully connected to Azure account {0}" -f $Acct.Id
    Set-AzureSubscription -SubscriptionName $SubscriptionName
    Select-AzureSubscription -SubscriptionName $SubscriptionName 
    Use-AzureHDInsightCluster $ClusterName

    inlinescript
    {
        $Environments = (Get-AzureAutomationVariable -AutomationAccountName 'Reports' -Name 'Environments').value.Split()
        $Environment = $Environments[0]

        $StudentTable = $Environment + 'Student'
        $OrganizationTable = $Environment + 'Organization'
        $GroupTable = $Environment + 'Group'
        $UserTable = $Environment + 'Users'

	    $UniqueStudentOrg = $Environment + "UniqueStudentOrg";
        $StudentUsageByDay = $Environment + "StudentUsageByDay";
        $StudentInformation1 = $Environment + 'StudentInformation1';
        
        $Query = "
	    ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        
        drop table if exists $StudentInformation1;
        create table $StudentInformation1
        (
          StudentID string,
          OrganizationID string,
          GroupID string,
          FirstName string,
          LastName string,
          GradeLevel int,
          StudentNumber string
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentInformation1';
        
        insert into table $StudentInformation1
          select 
              so.StudentID,
              so.organizationid,
              s.GroupID,
              s.FirstName,
              s.LastName,
              s.GradeLevel,
              s.StudentNumber
            from $UniqueStudentOrg so
              join ( 
                                select
                                    s.id,
                                    s.FirstName,
                                    s.LastName,
                                    s.GradeLevel,
                                    s.StudentNumber,
                                    c as GroupID
                                  from $StudentTable s
                                  LATERAL VIEW EXPLODE(s.Groups) st as c
                                  limit 1000000
                              ) as s on s.id = so.StudentID
        ;
        ";
#       $Query
        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Admin Report Usage Step 1" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
        
        
        $StudentInformation2 = $Environment + 'StudentInformation2'
        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        
        drop table if exists $StudentInformation2;
        create table $StudentInformation2
        (
          StudentID string,
          FirstName string,
          LastName string,
          GradeLevel string,
          StudentNumber string,
          OrganizationID string,
          OrganizationName string,
          GroupID string,
          GroupName string
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentInformation2';
        
        insert into table $StudentInformation2
          select 
              s.StudentID,
              s.FirstName,
              s.LastName,
              s.GradeLevel,
              s.StudentNumber,
              o.id,
              o.Name,
              g.id,
              g.Name
            from $StudentInformation1 s
              join $OrganizationTable o on o.id = s.organizationid
              join $GroupTable g on g.OrganizationID = o.id 
                and s.GroupID = g.id
        ;";
#        $Query
        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Admin Report Usage Step 2" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
        

        
        $StudentInformation = $Environment + 'StudentInformation'
        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        
        drop table if exists $StudentInformation;
        create table $StudentInformation
        (
          StudentID string,
          FirstName string,
          LastName string,
          GradeLevel string,
          StudentNumber string,
          OrganizationID string,
          OrganizationName string,
          GroupID string,
          GroupName string,
          UserFirstName string,
          UserLastName string
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentInformation';
        
        insert into table $StudentInformation
          select 
              s.StudentID,
              s.FirstName,
              s.LastName,
              s.GradeLevel,
              s.StudentNumber,
              s.OrganizationID,
              s.OrganizationName,
              s.GroupID,
              s.GroupName,
              u.FirstName,
              u.LastName
            from $StudentInformation2 s
              left outer join ( 
                                select distinct
                                    u.FirstName,
                                    u.LastName,
                                    c as GroupID
                                  from $UserTable u
                                  LATERAL VIEW EXPLODE(u.Groups) ut as c
                              ) as u on u.GroupID = s.GroupID
        ;";
#        $Query
        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Admin Report Usage Step 3" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
        
        
        $StudentInfoUsage = $Environment + "StudentInfoUsage";
        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        
        drop table if exists $StudentInfoUsage;
        create table $StudentInfoUsage
        (
          StudentID string,
          FirstName string,
          LastName string,
          GradeLevel int,
          StudentNumber string,
          OrganizationID string,
          OrganizationName string,
          GroupID string,
          GroupName string,
          UserFirstName string,
          UserLastName string,
          datetime timestamp, 
          elapsedseconds decimal(10,0)
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentInfoUsage';
        
        insert into table $StudentInfoUsage
          select --distinct 
              si.StudentID,
              si.FirstName,
              si.LastName,
              si.GradeLevel,
              si.StudentNumber,
              si.OrganizationID,
              si.OrganizationName,
              si.GroupID,
              si.GroupName,
              si.UserFirstName,
              si.UserLastName,
              --'',''
              su.datetime, 
              su.elapsedseconds 
            from $StudentInformation si
              join $StudentUsageByDay su on su.StudentID = si.StudentID
        ;";
#        $Query
        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Admin Report Usage Step 4" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob



<#        
        $Query = "
        drop table if exists $StudentInformation1;
        drop table if exists $StudentInformation2;
        drop table if exists $StudentInformation;
        ";
        $hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Admin Report Usage Step 5" -RunAsFile
        $hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob
#>
        
    }
    
}
