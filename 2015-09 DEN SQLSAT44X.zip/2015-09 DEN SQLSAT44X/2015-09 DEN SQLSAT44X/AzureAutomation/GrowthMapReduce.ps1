workflow GrowthMapReduce
{
	Param
	(
		[string]$Environment = 'Prod'
	)
		
	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$Creds = Get-AutomationPSCredential –Name 'automation'
    $StorageAccountName = Get-AutomationVariable –Name 'StorageAccountName'
	$GrowthMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "GrowthScaledScores" -ReturnTableProperties $true
	
	inlinescript
	{

		$SubscriptionName = $Using:SubscriptionName
		$Creds = $Using:Creds
		$Environment = $Using:Environment
		$ClusterName = $Using:ClusterName
		$StorageAccountName = $Using:StorageAccountName

		#Hive table that will have properties indicating it is a Mongodb table
		$Growth = $Environment + "GrowthScaledScores";
		$GrowthH = $Environment + "GrowthScaledScoresHive";
		
		#Write out Hive table with custom C# MapReduce job
		# ====== STORAGE ACCOUNT AND HDINSIGHT CLUSTER VARIABLES ======
		$containerName_App = "jars"
		$containerName_Data = "data"
		
		$Acct = Add-AzureAccount -Credential $Creds
		"Successfully connected to Azure account {0}" -f $Acct.Id
		Set-AzureSubscription -SubscriptionName $SubscriptionName -CurrentStorageAccount $StorageAccountName
		Select-AzureSubscription -SubscriptionName $SubscriptionName
		Use-AzureHDInsightCluster $ClusterName

		# ====== THE STREAMING MAPREDUCE JOB VARIABLES ======
		$mrMapper = "GrowthMapper.exe"
		$mrMapperFiles = $mrMapper,"$mrMapper.config","Castle.Core.dll","Common.Logging.Core.dll","Common.Logging.dll","Imagine.Data.Manager.dll","Imagine.Domain.Contracts.Manager.dll","Ninject.dll","Ninject.Extensions.Factory.dll"
		$mrMapperCmd = "$mrMapper $Environment"
		$mrReducer = "GrowthReducer.exe"
		$mrReducerFiles = $mrReducer,"$mrReducer.config","Castle.Core.dll","Common.Logging.dll"
		$mrReducerCmd = $mrReducer
		$mrAppRoot = "wasb://$containerName_App@$StorageAccountName.blob.core.windows.net/"
		$mrDataRoot = "wasb://$containerName_Data@$StorageAccountName.blob.core.windows.net/"
		$mrDir = "${mrAppRoot}GrowthMapReduce/"
		#The location of the flattened json documents that contain student data
		$mrInput = "${mrDataRoot}StudentData/${Environment}Docs/"
		$mrOutput = "${mrDataRoot}Data/$Growth/"

		#====== CLEAR PRIOR OUTPUT DIRECTORY ======
		Get-AzureStorageBlob -Container $containerName_Data -Blob "Data/$Growth/*" -ErrorAction SilentlyContinue | Remove-AzureStorageBlob
		Get-AzureStorageBlob -Container $containerName_Data -Blob "Data/$Growth"   -ErrorAction SilentlyContinue | Remove-AzureStorageBlob
		
		#====== CREATE A STREAMING MAPREDUCE JOB DEFINITION ======
		$mrJobDef = New-AzureHDInsightStreamingMapReduceJobDefinition -JobName "${environment}GrowthMrJob" -Mapper $mrMapperCmd -Reducer $mrReducerCmd -InputPath $mrInput -OutputPath $mrOutput
		$mrMapperFiles + $mrReducerFiles | Sort-Object -Unique | Foreach-Object { $mrJobDef.Files.Add($mrDir + $_) }
		
		#====== RUN A STREAMING MAPREDUCE JOB ======
		"Run Growth MapReduce job"
		$mrJob = Start-AzureHDInsightJob -Cluster $ClusterName -JobDefinition $mrJobDef
		"Hive job {0} : {1} started at {2}" -f $mrJob.Name, $mrJob.JobId, (Get-Date)
		$mrJob = Wait-AzureHDInsightJob -Job $mrJob -WaitTimeoutInSeconds 3600
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $mrJob.Name, $mrJob.JobId, (Get-Date), $mrJob.ExitCode
		
		"`nJob stdout:"
		Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $mrJob.JobId -StandardOutput

		if ($mrJob.ExitCode -ne 0) {
			"`nJob failed!"
			"Job stderr:"
			Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $mrJob.JobId -StandardError
			return
		}

		$Query = "
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
		
		set hive.execution.engine=tez;
 
 		--Creating a Hive view of the mapreduce job output in blob storage
		drop table if exists $GrowthH;
		create external table $GrowthH
		(
		  EntityId string,
		  WeekDate date,
		  AveragedScore double
		)
		stored as textfile location '$mrOutput';

		--First create & drop mongo collection to empty it out
		create table if not exists $Growth
		(
		  EntityId string,
		  WeekDate date,
		  AveragedScore double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		-- explicitly specify mappings to preserve case of field names
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
			""EntityId"":""EntityId"",
			""WeekDate"":""WeekDate"",
			""AveragedScore"":""AveragedScore""}') 
		$Using:GrowthMongoTableProperties;
		drop table $Growth;

		--Creating a Hive view of the mongo collection
		create table $Growth
		(
		  EntityId string,
		  WeekDate date,
		  AveragedScore double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		-- explicitly specify mappings to preserve case of field names
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
			""EntityId"":""EntityId"",
			""WeekDate"":""WeekDate"",
			""AveragedScore"":""AveragedScore""}') 
		$Using:GrowthMongoTableProperties;
	
		--insert into the mongo table the data
		insert overwrite table $Growth
		  select *
			from $GrowthH;
		";

		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Process $Environment generate Growth data, Send to Mongo" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob -WaitTimeoutInSeconds 5500
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`nJob stdout:"
		"Current record counts for {0} {1}" -f $Environment, "Growth" 
		Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardError
		}
	}
}
