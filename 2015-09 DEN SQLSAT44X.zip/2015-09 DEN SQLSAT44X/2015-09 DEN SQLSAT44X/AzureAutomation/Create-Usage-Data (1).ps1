workflow Create-Usage-Data
{
	Param
	(
		[string]$Environment = 'Prod'
	)

	$V2Environments = @("Test")

	"
	########################################################################
	#    StudentUsage for $Environment
	########################################################################
	"
	$StudentUsageStartTime = Get-Date
	$sresult = CreateStudentUsage -Environment $Environment
	$result = FlattenArrays -array $sresult
	$StudentUsageEndTime = Get-Date
	$OverallStudentUsageDiff = ($StudentUsageEndTime - $StudentUsageStartTime).ToString("hh\:mm")
	"CreateStudentUsage for $Environment`nDiff $OverallStudentUsageDiff`tStarted at $StudentUsageStartTime`tEnded at $StudentUsageEndTime.`n`n"
	$result
#    Checkpoint-Workflow


	"
	########################################################################
	#    GroupUsage for $Environment
	########################################################################
	"
	$GroupUsageStartTime = Get-Date
	$sresult = CreateGroupUsage -Environment $Environment
	$result = FlattenArrays -array $sresult
	$GroupUsageEndTime = Get-Date
	$OverallGroupUsageDiff = ($GroupUsageEndTime - $GroupUsageStartTime).ToString("hh\:mm")
	"CreateGroupUsage for $Environment`nDiff $OverallGroupUsageDiff`tStarted at $GroupUsageEndTime`tEnded at $GroupUsageEndTime.`n`n"
	$result
#    Checkpoint-Workflow


	"
	########################################################################
	#    OrganizationUsage for $Environment
	########################################################################
	"
	#       Note that OrganizationUsage uses a table created by GroupUsage, so it must run after GroupUsage queries
	$OrganizationUsageStartTime = Get-Date
	if ($V2Environments -contains $Environment)
	{
		$sresult = CreateOrganizationUsageV2 -Environment $Environment
	} 
	else 
	{
		$sresult = CreateOrganizationUsage -Environment $Environment
	}
	$result = FlattenArrays -array $sresult
	$OrganizationUsageEndTime = Get-Date
	$OverallOrganizationUsageDiff = ($OrganizationUsageEndTime - $OrganizationUsageStartTime).ToString("hh\:mm")
	"CreateOrganizationUsage for $Environment`nDiff $OverallOrganizationUsageDiff`tStarted at $OrganizationUsageStartTime`tEnded at $OrganizationUsageEndTime.`n`n"
	$result
#    Checkpoint-Workflow
}