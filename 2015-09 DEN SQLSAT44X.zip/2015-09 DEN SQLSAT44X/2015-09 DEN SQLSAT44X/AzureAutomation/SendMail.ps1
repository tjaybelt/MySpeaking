workflow SendMail
{

    Param
    (
        [string]$From = "CloudDataAutomaton@ImagineLearning.com",
        [string]$To = "DBCloudAlert@ImagineLearning.com",
        [string]$Subject = "Subject", 
        [string]$Body = "Body",
        [bool]$BodyAsHtml = $False
    )
	
    $Credential = Get-AutomationPSCredential –Name 'SendGrid'
    $SMTPServer = Get-AutomationVariable –Name 'SMTPServer'
    $SMTPPort = Get-AutomationVariable –Name 'SMTPPort'
    
    inlinescript
    {
        $SendMailParameters = @{
          From = $Using:From
          To = ($Using:To).Split(",")
          Subject = $Using:Subject
          Body = $Using:Body
          SmtpServer = $Using:SMTPServer
          Port = $Using:SMTPPort
          UseSsl = $True
          Credential = $Using:Credential
          BodyAsHtml = $Using:BodyAsHtml
        }
        
        
        Start-Sleep -s 10
        
        Send-MailMessage @SendMailParameters
    }
}
