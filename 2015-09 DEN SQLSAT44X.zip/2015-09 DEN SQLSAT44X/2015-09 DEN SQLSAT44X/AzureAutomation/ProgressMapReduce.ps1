workflow ProgressMapReduce
{
	Param
	(
		[string]$Environment = 'Prod'
	)
		
	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$Creds = Get-AutomationPSCredential –Name 'automation'
    $StorageAccountName = Get-AutomationVariable –Name 'StorageAccountName'
	$StudentProgressMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentProgress" -ReturnTableProperties $true
	
	inlinescript
	{
		$SubscriptionName = $Using:SubscriptionName
		$Creds = $Using:Creds
		$Environment = $Using:Environment
		$ClusterName = $Using:ClusterName
		$StorageAccountName = $Using:StorageAccountName

		
		#Hive table that will have properties indicating it is a Mongodb table
		$StudentProgress = $Environment + "StudentProgress";
		$StudentProgressH = $Environment + "StudentProgressHive";
		
		#Write out Hive table with custom C# MapReduce job
		# ====== STORAGE ACCOUNT AND HDINSIGHT CLUSTER VARIABLES ======
		$containerName_App = "jars"
		$containerName_Data = "data"
		
		$Acct = Add-AzureAccount -Credential $Creds
		"Successfully connected to Azure account {0}" -f $Acct.Id
		Set-AzureSubscription -SubscriptionName $SubscriptionName -CurrentStorageAccount $StorageAccountName
		Select-AzureSubscription -SubscriptionName $SubscriptionName
		Use-AzureHDInsightCluster $ClusterName

		# ====== THE STREAMING MAPREDUCE JOB VARIABLES ======
		$mrMapper = "Imagine.Reports.Progress.Mapper.exe"
		$mrMapperFiles =  $mrMapper,"$mrMapper.config","AzureEncryptionExtensions.dll","Base62.dll","Castle.Core.dll","Common.Logging.Core.dll","Common.Logging.dll","Common.Logging.Log4Net1213.dll",
			"Imagine.Data.ActivityRecordingStorage.dll","Imagine.Data.dll","Imagine.Data.Manager.dll","Imagine.Data.MongoDB.dll","Imagine.Data.MongoDB.Manager.dll",
			"Imagine.Domain.Contracts.Manager.dll","Imagine.Domain.dll","Imagine.Domain.Manager.dll",
			"Imagine.Reports.Common.dll","Imagine.Reports.DataModel.Cloud.dll","Imagine.Reports.DataModel.Contracts.dll","Imagine.Reports.DataModel.Implementations.dll",
			"Imagine.Reports.DataModel.JSON.dll","Imagine.Reports.DataModel.Sequencer.dll","Imagine.Reports.DomainLogic.dll","Imagine.Reports.DomainModel.dll",
			"Imagine.Sequencer.DataModel.Contracts.dll",
			"Imagine.Sequencer.DataModel.StudentDocument.dll","Imagine.Sequencer.DomainModel.CodeGenRefData.dll","Imagine.Sequencer.DomainModel.dll",
			"Imagine.Sequencer.NinjectRegistrations.Cloud.dll",
			"Imagine.Util.dll",
			"log4net.dll","Microsoft.WindowsAzure.Storage.dll","MongoDB.Bson.dll","MongoDB.Driver.Core.dll","MongoDB.Driver.dll","Newtonsoft.Json.dll",
			"Ninject.dll","Ninject.Extensions.Factory.dll","Nito.AsyncEx.dll","Z.ExtensionMethods.dll"
		$mrMapperCmd = "$mrMapper $Environment"
		$mrAppRoot = "wasb://$containerName_App@$StorageAccountName.blob.core.windows.net/"
		$mrDataRoot = "wasb://$containerName_Data@$StorageAccountName.blob.core.windows.net/"
		$mrDir = "${mrAppRoot}pmr/"
		#The location of the flattened json documents that contain student data
		$mrInput = "${mrDataRoot}StudentData/${Environment}Docs/"
		$mrOutput = "${mrDataRoot}Data/$StudentProgress/"

		#====== CLEAR PRIOR OUTPUT DIRECTORY ======
		Get-AzureStorageBlob -Container $containerName_Data -Blob "Data/$StudentProgress/*" -ErrorAction SilentlyContinue | Remove-AzureStorageBlob
		Get-AzureStorageBlob -Container $containerName_Data -Blob "Data/$StudentProgress"   -ErrorAction SilentlyContinue | Remove-AzureStorageBlob
		
		#====== CREATE A STREAMING MAPREDUCE JOB DEFINITION ======
		$mrJobDef = New-AzureHDInsightStreamingMapReduceJobDefinition -JobName "${environment}ProgressMrJob" -Mapper $mrMapperCmd -InputPath $mrInput -OutputPath $mrOutput
		$mrMapperFiles | Sort-Object -Unique | Foreach-Object { $mrJobDef.Files.Add($mrDir + $_) }
		
		#====== RUN A STREAMING MAPREDUCE JOB ======
		"Run Progress MapReduce job"
		$mrJob = Start-AzureHDInsightJob -Cluster $ClusterName -JobDefinition $mrJobDef
		"Hive job {0} : {1} started at {2}" -f $mrJob.Name, $mrJob.JobId, (Get-Date)
		$mrJob = Wait-AzureHDInsightJob -Job $mrJob -WaitTimeoutInSeconds 3600
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $mrJob.Name, $mrJob.JobId, (Get-Date), $mrJob.ExitCode
		
		"`nJob stdout:"
		Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $mrJob.JobId -StandardOutput

		if ($mrJob.ExitCode -ne 0) {
			"`nJob failed!"
			"Job stderr:"
			Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $mrJob.JobId -StandardError
			return
		}

		$Query = "
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
		
		set hive.execution.engine=tez;
 
 		--Creating a Hive view of the mapreduce job output in blob storage
		drop table if exists $StudentProgressH;
		create external table $StudentProgressH
		(
		  StudentId string, 
		  OrganizationId string, 
		  TimePeriod string,
		  EndDate date,
		  ProgressAreaId string,
		  HighestLessonPriorProgress string,
		  HighestLessonTimePeriodProgress string,
		  AllLessonsSkipped boolean,
		  SkillLevel string
		)
		stored as textfile location '$mrOutput';

		--First create & drop mongo collection to empty it out
		create table if not exists $StudentProgress
		(
		  StudentId string, 
		  OrganizationId string, 
		  TimePeriod string,
		  EndDate date,
		  ProgressAreaId string,
		  HighestLessonPriorProgress string,
		  HighestLessonTimePeriodProgress string,
		  AllLessonsSkipped boolean,
		  SkillLevel string
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		-- explicitly specify mappings to preserve case of field names
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
		  ""StudentId"" : ""StudentId"", 
		  ""OrganizationId"" : ""OrganizationId"",
		  ""TimePeriod"" : ""TimePeriod"",
		  ""EndDate"" : ""EndDate"",
		  ""ProgressAreaId"" : ""ProgressAreaId"",
		  ""HighestLessonPriorProgress"" : ""HighestLessonPriorProgress"",
		  ""HighestLessonTimePeriodProgress"" : ""HighestLessonTimePeriodProgress"",
		  ""AllLessonsSkipped"" : ""AllLessonsSkipped"",
		  ""SkillLevel"" : ""SkillLevel""}') 
		$Using:StudentProgressMongoTableProperties;
		drop table $StudentProgress;

		--Creating a Hive view of the mongo collection
		create table $StudentProgress
		(
		  StudentId string, 
		  OrganizationId string, 
		  TimePeriod string,
		  EndDate date,
		  ProgressAreaId string,
		  HighestLessonPriorProgress string,
		  HighestLessonTimePeriodProgress string,
		  AllLessonsSkipped boolean,
		  SkillLevel string
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		-- explicitly specify mappings to preserve case of field names
		with SERDEPROPERTIES( 'mongo.columns.mapping' = '{
		  ""StudentId"" : ""StudentId"", 
		  ""OrganizationId"" : ""OrganizationId"",
		  ""TimePeriod"" : ""TimePeriod"",
		  ""EndDate"" : ""EndDate"",
		  ""ProgressAreaId"" : ""ProgressAreaId"",
		  ""HighestLessonPriorProgress"" : ""HighestLessonPriorProgress"",
		  ""HighestLessonTimePeriodProgress"" : ""HighestLessonTimePeriodProgress"",
		  ""AllLessonsSkipped"" : ""AllLessonsSkipped"",
		  ""SkillLevel"" : ""SkillLevel""}') 
		$Using:StudentProgressMongoTableProperties;
		
		--insert into the mongo table the data
		insert overwrite table $StudentProgress
		  select *
			from $StudentProgressH;
		"
	
		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Process $Environment generate StudentProgress data, Send to Mongo" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob -WaitTimeoutInSeconds 5500
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`nJob stdout:"
		Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardError
		}
	}
}