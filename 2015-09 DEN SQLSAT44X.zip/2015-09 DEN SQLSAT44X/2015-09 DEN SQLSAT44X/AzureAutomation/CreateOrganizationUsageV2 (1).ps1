workflow CreateOrganizationUsageV2
{
	Param
	(
		[string]$Environment = 'Prod'
	)

	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$credential = Get-AutomationPSCredential –Name 'SendGrid'
	$Creds = Get-AutomationPSCredential –Name 'automation'

	$StorageAccountName = Get-AutomationVariable –Name 'StorageAccountName'
	$StorageAccountKey = Get-AutomationVariable –Name 'StorageAccountKey'

	$Acct = Add-AzureAccount -Credential $Creds
	"Successfully connected to Azure account {0}" -f $Acct.Id
	Set-AzureSubscription -SubscriptionName $SubscriptionName 
	Select-AzureSubscription -SubscriptionName $SubscriptionName
	Use-AzureHDInsightCluster $ClusterName

	$MongoConnectionString = MongoConnectionString -Environment $Environment -Database $nul -Collection $nul -ReturnTableProperties $false
	$StudentUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsage" -ReturnTableProperties $true
	$OrganizationMongoTableProperties = MongoConnectionString -Environment $Environment -Database $nul -Collection "Organization" -ReturnTableProperties $true
	$OrganizationCountMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "OrganizationCount" -ReturnTableProperties $true
	$OrganizationUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "OrganizationUsage" -ReturnTableProperties $true

	inlinescript
	{
		$Environment = $Using:Environment
		$SubscriptionName = $Using:SubscriptionName
		$StorageAccountName = $Using:StorageAccountName
		$StorageAccountConnectionString = $Using:StorageAccountConnectionString

		$StudentTable = $Environment + "Student"
		$OrgsTable = $Environment + "Orgs"
		$OrgCount = $Environment + "OrgCount"
		$OrgUsage = $Environment + "OrgUsage"
		$OrgUsageH = $Environment + "OrgUsageHive"
		$StudentOrg = $Environment + "StudentOrg"
		$UniqueStudentOrg = $Environment + "UniqueStudentOrg"
		$StudentUsage = $Environment + "StudentUsage2";
		$StudentUsageH = $Environment + "StudentUsageHive";
		# NOTE: This expects the xUniqueStudentGroup to have already been populated
		$UniqueStudentGroup = $Environment + "UniqueStudentGroup"

		# Download and run the OrgTreeToHiveTable tool
		"Fetching OrgTreeToHiveTable executable"
		Set-AzureSubscription -SubscriptionName $SubscriptionName -CurrentStorageAccount $StorageAccountName
		Get-AzureStorageBlob -Blob OrgTreeToHiveTable/* -Container tools | Get-AzureStorageBlobContent -Destination $env:Temp -Force
		$dllPath = $env:Temp + "\OrgTreeToHiveTable"

		Add-Type -Path "$dllPath\MongoDB.Driver.Core.dll"
		Add-Type -Path "$dllPath\MongoDB.Bson.dll"
		Add-Type -Path "$dllPath\MongoDB.Driver.dll"
		Add-Type -Path "$dllPath\OrgTreeToHiveTable.dll"
		Add-Type -Path "$dllPath\Microsoft.WindowsAzure.Storage.dll"

		# Connect to Mongo
		$mongoUrl = New-Object MongoDB.Driver.MongoUrl $using:MongoConnectionString
		$mongoClient = New-Object MongoDB.Driver.MongoClient $mongoUrl
		$mongoDatabase = $mongoClient.GetDatabase($mongoUrl.DatabaseName)

		# Convert the org tree into a hive table
		$orgTreeReader = New-Object OrgTreeToHiveTable.OrgTreeReader $mongoDatabase
		$orgTreeEntries = $orgTreeReader.GetLatestOrgTree()
		$orgPairs = [OrgTreeToHiveTable.OrgTreeToAncestorPairConverter]::Convert($orgTreeEntries)
		$bytes =  [OrgTreeToHiveTable.HiveTableUtilities]::ConvertToHiveTable($orgPairs)
		[IO.File]::WriteAllBytes("$env:Temp\HiveTable.dat",$bytes)

		# Remove any old files
		Get-AzureStorageBlob -Container data -Blob ("OrgData/" + $OrgsTable + "/*") | Remove-AzureStorageBlob
		# Upload the resulting hive table to blob storage
		Set-AzureStorageBlobContent -Blob ("OrgData/" + $OrgsTable + "/00000") -Container data -File $env:Temp\HiveTable.dat -Force



		$Query = "
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;

		--OrgTree type table
		drop table if exists $OrgsTable;
		create external table $OrgsTable
		(
		  organizationid string,
		  childorganizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$OrgsTable';

		--Generate Students Organizations - because cant do a lateral view explosion and a join
		drop table if exists $StudentOrg;
		create external table $StudentOrg
		(
		  studentid string,
		  organizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$StudentOrg';


		insert overwrite table $StudentOrg
		  select
			  id as studentid,
			  columnAlias as organizationid
			from $StudentTable S
			LATERAL VIEW EXPLODE(S.Organizations) tableAlias as columnAlias;



		--unique students that pertain to each organization
		--for each organization and level, collect all students, and then get usage by gathering distinct student usage
		drop table if exists $UniqueStudentOrg;
		create external table $UniqueStudentOrg
		(
		  studentid string,
		  organizationid string
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/OrgData/$UniqueStudentOrg';

		with cteOrgs as
		(
		select
			o.organizationid,
			o.childorganizationid
		  from $OrgsTable o
		)
		insert overwrite table $UniqueStudentOrg
		  select distinct
			  so.studentid,
			  o.organizationid
			from $StudentOrg so 
			left outer join cteOrgs o on o.childorganizationid = so.organizationid;


		--number of active unique students in each organization
		--where active is currently defined as belonging to a group, though it may eventually be tied to licenses

		-- we want to clear out the existing OrgCount table in Mongo...
		-- if the Hadoop cluster is new we might not have an existing connection to the table,
		-- so create the connection (not external) then to clear it out drop it and recreate it 
		create table if not exists $OrgCount
		(
			organizationid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationCountMongoTableProperties;
		drop table $OrgCount;
		create table $OrgCount
		(
			organizationid string,
			numstudents int
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationCountMongoTableProperties;

		insert overwrite table $OrgCount
		  select
			organizationid,
			count(*)
		  from $UniqueStudentOrg uso
		  inner join $UniqueStudentGroup usg on uso.studentid = usg.studentid
		  group by organizationid;

		--need to rename this table, so that we can point to it as a double, not a float, because data types are hard
		drop table if exists $StudentUsage;
		create external table if not exists $StudentUsage
		(
		  studentid string,
		  collectedyear int,
		  collectedweek int,
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;



		--Generate Students associated to Organizations
		--This will create a HIVE table that has properties that make it a Mongo table. 
		create table if not exists $OrgUsage
		(
		  organizationid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationUsageMongoTableProperties;

		select '';
		select 'Before Count of $OrgUsage';
		select '-----------------------------';
		select count(*) from $OrgUsage;
		select '';

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table $OrgUsage;

		--Then we need to create it again, so that it is empty and ready to be filled by the insertoverwrite, which only fills, not overwrites.
		create table $OrgUsage
		(
		  organizationid string,
		  collectedyear int,
		  collectedweek int,
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:OrganizationUsageMongoTableProperties;

		insert overwrite table $OrgUsage
		  select
			  so.organizationid,
			  su.collectedyear,
			  su.collectedweek,
			  sum(su.elapsedseconds) as elapsedseconds
			from $UniqueStudentOrg so
			  join $StudentUsage su on su.studentid = so.studentid
			group by
			  so.organizationid,
			  su.collectedyear,
			  su.collectedweek;

		select 'After Count of $OrgUsage';
		select '-----------------------------';
		select count(*) from $OrgUsage;
		select '';


		drop table if exists $OrgUsageH;
		create external table $OrgUsageH
		(
		  organizationid string,
		  datetime date,
		  elapsedseconds float
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$OrgUsageH';

		insert overwrite table $OrgUsageH
		  select
			  so.organizationid,
			  su.datetime,
			  sum(su.elapsedseconds) as elapsedseconds
			from $UniqueStudentOrg so
			  join $StudentUsageH su on su.studentid = so.studentid
			group by
			  so.organizationid,
			  su.datetime;
		";

		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Process $Environment OrganizationUsage" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $Using:ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob -WaitTimeoutInSeconds 5500
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`n{0} {1}" -f $Environment, "OrganizationUsage"
		"`nJob stdout:"
		"--------------------------------------------------------------------------------------------" 
		Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			"--------------------------------------------------------------------------------------------" 
			Get-AzureHDInsightJobOutput -Cluster $Using:ClusterName -JobId $hiveJob.JobId -StandardError
			"--------------------------------------------------------------------------------------------" 
		}
	}
}
