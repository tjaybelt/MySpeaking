workflow DestroyHDCluster-Scheduled
{
#    [string]$MailSubject = Get-AutomationVariable –Name 'Subject'
#    [string]$MailFrom = Get-AutomationVariable –Name 'From'
#    [string]$MailTo = Get-AutomationVariable –Name 'To'
    
    #only destroy the cluster if it is not the weekend   
    If ((Get-Date).DayOfWeek -ne 'Saturday' -and (Get-Date).DayOfWeek -ne 'Sunday') 
    {
#       $StartTime = Get-Date
#       $sresult = DestroyHDCluster
#       $result = FlattenArrays -array $sresult
#       $EndTime = Get-Date
#       $Diff = (New-TimeSpan –Start $StartTime –End $EndTime).minutes
#       SendMail -From $MailFrom -To $MailTo -Subject $MailSubject `
#         -Body "HDinsight Cluster Destroyed.`n`nDiff $Diff (minutes)`nStarted at $StartTime`nEnded at $EndTime.`n`nAzure Automation has processed the ETL of Student documents data via HDInsight"

########DestroyHDCluster

    }
}


