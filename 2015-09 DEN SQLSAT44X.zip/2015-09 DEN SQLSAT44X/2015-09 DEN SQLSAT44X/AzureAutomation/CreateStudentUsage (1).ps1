workflow CreateStudentUsage
{
	Param
	(
		[string]$Environment = 'Prod'
	)
		
	$SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName' 
	$ClusterName = Get-AutomationVariable –Name 'ClusterName'
	$credential = Get-AutomationPSCredential –Name 'SendGrid'
	$Creds = Get-AutomationPSCredential –Name 'automation'

	$StudentUsageMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsage" -ReturnTableProperties $true
	$StudentUsageByDayMongoTableProperties = MongoConnectionString -Environment $Environment -Database "reports" -Collection "StudentUsageByDay" -ReturnTableProperties $true
	
	inlinescript
	{

		$SubscriptionName = $Using:SubscriptionName
		$Creds = $Using:Creds
		$Environment = $Using:Environment
		$ClusterName = $Using:ClusterName

		#The location of the flattened json documents that contain student data
		$DocTable = $Environment + "Docs"
		$JSonLocation = "wasb://data@ilreportdata.blob.core.windows.net/StudentData/$DocTable";
		
		#Hive table that will pull out Activity Counted data about students
		$DocsActivityCounted = $Environment + "DocsActivityCounted";
		
		#Hive table that will have properties indicating it is a Mongodb table
		$StudentUsage = $Environment + "StudentUsage";
		$StudentUsageH = $Environment + "StudentUsageHive";
		$StudentUsageByDay = $Environment + "StudentUsageByDay";
		#$StudentUsageByDayH = $Environment + "StudentUsageByDayHive";

		$Acct = Add-AzureAccount -Credential $Creds
		"Successfully connected to Azure account {0}" -f $Acct.Id
		Set-AzureSubscription -SubscriptionName $SubscriptionName
		Select-AzureSubscription -SubscriptionName $SubscriptionName
		Use-AzureHDInsightCluster $ClusterName

		$Query = "
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/json-serde-1.3-jar-with-dependencies.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
		ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
		
		set hive.execution.engine=tez;

		--This will be the HIVE table that points to the flattened student docs, and it will contain activity counted data for students		
		drop table if exists $DocsActivityCounted;
		CREATE EXTERNAL TABLE IF NOT EXISTS $DocsActivityCounted (
		  id string,
		  activitycountedcollection array<struct<datetime:string, elapsedseconds:double>>
		)
		ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
		WITH SERDEPROPERTIES ( ""mapping.id"" = ""_id"" )
		LOCATION '$JSonLocation';

		--This will create a HIVE table that has properties that make it a Mongo table. 
		drop table if exists $StudentUsageH;
		create external table $StudentUsageH
		(
		  studentid string, 
		  datetime date, 
		  elapsedseconds float
		)
		stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$StudentUsageH';

		--

		--query the flattened student docs that contain the activity counted data for students and sumarize this data into Student Usage and deposit it in a table with MongoDB properties.
		--calculate week of year using Java's from_unixtime because it works off Sunday-Saturday weeks
		--  whereas the builtin WEEKOFYEAR function works off Monday-Sunday weeks
		WITH q1 AS (
		  SELECT 
			  S.id,
			  TO_DATE(coll.lessonbranch.datetime) as datetime,
			  case
				when coll.lessonbranch.elapsedseconds >= 2000 then 300
				else coll.lessonbranch.elapsedseconds
			  end as elapsedseconds 
			FROM $DocsActivityCounted S 
			LATERAL VIEW EXPLODE(S.activitycountedcollection) coll as lessonbranch
			--where S.id = '763e584d-0824-47d0-b1ae-30f6cb1ce587'
			--limit 100 
		)
		insert overwrite table $StudentUsageH
		  SELECT 
			  id,
			  datetime,
			  SUM(elapsedseconds) as elapsedseconds
			FROM q1
			GROUP BY
			  id,
			  datetime
			order by
			  datetime,
			  id
		;


		--This will create a HIVE table that has properties that make it a Mongo table. 
		--It will contain StudentUsage with a sum of usage for Year and WeekOfYear 
		create table if not exists $StudentUsage 
		(
		  studentid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;

		select count(*) from $StudentUsage;

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table if exists $StudentUsage;

		--Then we need to create it again, so that it is empty and ready to be filled by the insertoverwrite, which only fills, not overwrites.
		create table if not exists $StudentUsage 
		(
		  studentid string, 
		  collectedyear int, 
		  collectedweek int, 
		  elapsedseconds float
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageMongoTableProperties;
		
		--insert into a mongo table the data         
		insert overwrite table $StudentUsage
		  select 
			  studentid,
			  from_unixtime(unix_timestamp(datetime, 'yyyy-MM-dd'),'Y') as year,
			  from_unixtime(unix_timestamp(datetime, 'yyyy-MM-dd'),'w') as weekofyear,
			  sum(elapsedseconds)
			from $StudentUsageH
			GROUP BY
			  studentid,
			  from_unixtime(unix_timestamp(datetime, 'yyyy-MM-dd'),'Y'),
			  from_unixtime(unix_timestamp(datetime, 'yyyy-MM-dd'),'w')
			order by
			  year,
			  weekofyear,
			  studentid
		;

		select count(*) from $StudentUsage;
		
		
		--This will create a HIVE table that has properties that make it a Mongo table. 
		--It will contain StudentUsage with a sum of usage for each day
		create table if not exists $StudentUsageByDay 
		(
		  studentid string, 
		  datetime timestamp, 
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageByDayMongoTableProperties;

		--But we need to drop it after it was created, so that the mongo table actually is dropped.
		drop table if exists $StudentUsageByDay;

		--Then we need to create it again, so that it is empty and ready to be filled by the insertoverwrite, which only fills, not overwrites.
		create table if not exists $StudentUsageByDay 
		(
		  studentid string, 
		  datetime timestamp, 
		  elapsedseconds double
		)
		stored by 'com.mongodb.hadoop.hive.MongoStorageHandler'
		$Using:StudentUsageByDayMongoTableProperties;
		
		--insert into a mongo table the data         
		insert overwrite table $StudentUsageByDay
		  select 
			  studentid,
			  datetime,
			  elapsedseconds
			from $StudentUsageH
		;      
		";

		$hiveJobDefinition = New-AzureHDInsightHiveJobDefinition -Query $Query -JobName "Process $Environment ActivityCounted data, generate StudentUsage data, Send to Mongo" -RunAsFile
		$hiveJob = Start-AzureHDInsightJob -JobDefinition $hiveJobDefinition -cluster $ClusterName
		"Hive job {0} : {1} started at {2}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date)
		$hiveJob = Wait-AzureHDInsightJob -Job $hiveJob -WaitTimeoutInSeconds 5500
		"Hive job {0} : {1} finished at {2} with exit code {3}" -f $hiveJob.Name, $hiveJob.JobId, (Get-Date), $hiveJob.ExitCode
		"`nJob stdout:"
		"Previous and current record counts for {0} {1}" -f $Environment, "StudentUsage" 
		Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardOutput 
		if ($hiveJob.ExitCode -ne 0) {
			"Job failed!"
			"`nJob stderr:"
			Get-AzureHDInsightJobOutput -Cluster $ClusterName -JobId $hiveJob.JobId -StandardError
		}
	}
}
