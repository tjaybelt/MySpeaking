workflow MongoConnectionString
{
	Param
	(
		[string]$Environment,
		[string]$Database,
		[string]$Collection,
		[bool]$ReturnTableProperties
	)
	
	if ($Database -ne $null -and $Database -ne '') { $Database = "_" + $Database }
	if ($Collection -ne $null -and $Collection -ne '') { $Collection = "." + $Collection }
	switch -Casesensitive ($Environment) {
		'Test' { $connectionString = "mongodb://appAdmin:w8WvVdVt4SFO@Test-Mongo-1.my.imaginelearning.com:27017/test$($Database)$($Collection)?authsource=admin&replicaSet=RS-TestV2-0&readPreference=secondary&ssl=true"}
		'Prod' { $connectionString = "mongodb://appAdmin:Jw2ktqywlX5u@SG-Production-4187.servers.mongodirector.com:27017/production$($Database)$($Collection)?authsource=admin&replicaSet=RS-Production-0&readPreference=secondary" }
		'RC'   { $connectionString = "mongodb://appAdmin:t6SfOw8WvVdV@SG-RC-4404.servers.mongodirector.com:27017/rc$($Database)$($Collection)?authsource=admin&readPreference=secondary" }
		'Demo' { $connectionString = "mongodb://appAdmin:tqlX6ywTw3ku@SG-Demo-4405.servers.mongodirector.com:27017/demo$($Database)$($Collection)?authsource=admin&readPreference=secondary" }
	}

	if ($returnTableProperties)
	{
		return "TBLPROPERTIES( 'mongo.uri' = '$connectionString' )"
	}
	
	return $connectionString
}
