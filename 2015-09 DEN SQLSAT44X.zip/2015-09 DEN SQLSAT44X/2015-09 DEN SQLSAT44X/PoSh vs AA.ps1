﻿
		function MongoConnectionStrings($Env, $Db, $Coll) {
			if ($Db) { $Db = "_" + $Db }
			if ($Coll) { $Coll = "." + $Coll }
			switch ($Env) {
				'Test' { return "mongodb://appAdmin:w8WvVdVt4SFO@SG-Test-3878.servers.mongodirector.com:27017/test$($Db)$($Coll)?authsource=admin&replicaSet=RS-Test-0" }
				#'Test' { return "mongodb://appAdmin:w8WvVdVt4SFO@SG-Test2-5229.servers.mongodirector.com:27017/test$($Db.$($Coll)?authsource=admin&replicaSet=RS-Test2-0" }
				'Prod' { return "mongodb://appAdmin:Jw2ktqywlX5u@SG-Production-4187.servers.mongodirector.com:27017/production$($Db)$($Coll)?authsource=admin&replicaSet=RS-Production-0" }
				'RC'   { return "mongodb://appAdmin:t6SfOw8WvVdV@SG-RC-4404.servers.mongodirector.com:27017/rc$($Db)$($Coll)?authsource=admin" }
				'Demo' { return "mongodb://appAdmin:tqlX6ywTw3ku@SG-Demo-4405.servers.mongodirector.com:27017/demo$($Db)$($Coll)?authsource=admin" }
			}
		}


		function MongoConnectionString($Env, $Db, $Coll) {
			if ($Db -ne '') { $Db = "_" + $Db }
			switch ($Env) {
				'Test' { return "TBLPROPERTIES( 'mongo.uri' = 'mongodb://appAdmin:w8WvVdVt4SFO@SG-Test-3878.servers.mongodirector.com:27017/test$($Db).$($Coll)?authsource=admin&replicaSet=RS-Test-0' )" }
				'Prod' { return "TBLPROPERTIES( 'mongo.uri' = 'mongodb://appAdmin:Jw2ktqywlX5u@SG-Production-4187.servers.mongodirector.com:27017/production$($Db).$($Coll)?authsource=admin&replicaSet=RS-Production-0')" }
				'RC'   { return "TBLPROPERTIES( 'mongo.uri' = 'mongodb://appAdmin:t6SfOw8WvVdV@SG-RC-4404.servers.mongodirector.com:27017/rc$($Db).$($Coll)?authsource=admin')" }
				'Demo' { return "TBLPROPERTIES( 'mongo.uri' = 'mongodb://appAdmin:tqlX6ywTw3ku@SG-Demo-4405.servers.mongodirector.com:27017/demo$($Db).$($Coll)?authsource=admin')" }
			}
		}

        $Environments = (Get-AzureAutomationVariable -AutomationAccountName 'Reports' -Name 'Environments').value.Split()
        $Environment = $Environments[0]
		$OrgTree = $Environment + "OrgTree"
		$OrgTreeData = $Environment + "OrgTreeData"
		$MyOrganizationTable = $Environment + "MyOrganization"
		$OrganizationMongoConnectionString = MongoConnectionString $Environment "" "Organization"

        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        ";

#--------------------------------------

workflow Collect-AdminReportOrgData
{

    $Credential = Get-AutomationPSCredential –Name 'automation'
    $SubscriptionName = Get-AutomationVariable –Name 'SubscriptionName'
    $ClusterName = Get-AutomationVariable –Name 'ClusterName'
    $Acct = Add-AzureAccount -Credential $Credential
	"Successfully connected to Azure account {0}" -f $Acct.Id
    Set-AzureSubscription -SubscriptionName $SubscriptionName
    Select-AzureSubscription -SubscriptionName $SubscriptionName 
    Use-AzureHDInsightCluster $ClusterName
 
	$Environments = (Get-AzureAutomationVariable -AutomationAccountName 'Reports' -Name 'Environments').value.Split()
	$OrganizationMongoConnectionString = MongoConnectionString -Environment $Environments[0] -Database $nul -Collection "Organization" -ReturnTableProperties $true

    inlinescript
    {
        $ClusterName = $Using:ClusterName
        $Environment = $Using:Environments[0]
        
		$OrgTree = $Environment + "OrgTree"
		$OrgTreeData = $Environment + "OrgTreeData"
		$MyOrganizationTable = $Environment + "MyOrganization"
		$OrganizationMongoConnectionString = $Using:OrganizationMongoConnectionString

        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;
        ";
