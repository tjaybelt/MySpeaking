﻿        $Query = "
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-java-driver-2.13.0.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-core-1.3.2.jar;
        ADD JAR  wasb://jars@ilreportdata.blob.core.windows.net/mongo-hadoop-hive-1.3.2.jar;


        drop table if exists $CloudAdoption;
        create table $CloudAdoption
        (
          type string,
	      environment string,
          datetime timestamp,
          count int
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$CloudAdoption';
        drop table if exists $CloudAdoption;

        drop table if exists $CloudAdoption;
        create external table $CloudAdoption
        (
          type string,
	      environment string,
          count int
        )
        stored as textfile location 'wasb://data@ilreportdata.blob.core.windows.net/Data/$CloudAdoption';

	    insert into table $CloudAdoption
          select 
              case 
                when ot.organizationtype = 0 then 'Districts'
                when ot.organizationtype = 1 then 'Schools'
                when ot.organizationtype = 2 then 'Other'
              end,
              ""$Environment"",
              count(*) 
            from $OrgsTable o
            left outer join $OrganizationTable ot on ot.id = o.childorganizationid
            where o.organizationid = '00000000-0000-0000-0000-000000000004'
              and ot.SiteCode is not null
            group by ot.organizationtype
        ;
        ";
