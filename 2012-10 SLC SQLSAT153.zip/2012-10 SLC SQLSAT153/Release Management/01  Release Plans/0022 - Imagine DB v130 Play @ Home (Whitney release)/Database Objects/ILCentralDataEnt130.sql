USE ILCentralDataEnt
GO

ALTER TABLE [dbo].[Group] ADD
[GroupTypeId] [tinyint] NULL

ALTER TABLE [dbo].[Institution] ADD
[PlayAtHomeEnabled] [bit] NULL
