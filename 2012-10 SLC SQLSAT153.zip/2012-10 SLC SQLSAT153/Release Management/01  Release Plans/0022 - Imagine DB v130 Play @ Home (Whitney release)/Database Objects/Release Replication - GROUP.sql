/****************************************************************************************************
 Replication : 

 SQL Server Native replication can be impacted by a schema change. 

 The template below is used to apply schema changes and make any applicable replication
 changes for SQL Server Native.

 This template consists of a number of steps. Some steps may not be required, depending
 on the type of schema change that and its impact on replication. 

****************************************************************************************************
 Execute the output of this script at Publisher on the corresponding publication database.
 NOTE: In Management Studio or Query Analyzer, be sure to set "Maximum Number of characters..." 
	 for the "TEXT" output to 8000
****************************************************************************************************/

Search and Replace the following phrases
    ILCentralDataEnt
    Group
    ILCentralDataEnt


/****************************************************************************************************
 1. Replication Clean Up & Prep
 
    This step will remove table(s) that are part of a publication, in preparation for the 
    necessary schema changes for a release
    
    If the table(s) are part of a SQL Server Publication and one or more of the following  
    types of changes are being made to the table(s):
      - altering an existing column
      - changing the datatype of a column
      - some other options should exist here

****************************************************************************************************/

-- Dropping the articles
use [ILCentralDataEnt]
go

exec sp_dropsubscription 
  @publication = N'ILCentralDataEnt', 
  @article = N'Group', 
  @subscriber = N'all', 
  @destination_db = N'all'
GO

exec sp_droparticle 
  @publication = N'ILCentralDataEnt', 
  @article = N'Group', 
  @force_invalidate_snapshot = 1
GO


/****************************************************************************************************
 2. Actual Schema Changes

    This step will cause the schema changes and any new tables to be applied. 
    If new tables are being added in a release, they will be included in this
    section too.

****************************************************************************************************/




/****************************************************************************************************
 3. Create script to Amend Publications

    Run this script in (Publisher machine) the Query Analyzer to 
    add articles to the publication. 
    Provide applicable values for
      Group
      ILCentralDataEnt

****************************************************************************************************/

exec sp_addarticle 
        @publication = N'ILCentralDataEnt', 
        @article = N'Group', 
        @source_owner = N'dbo', 
        @source_object = N'Group', 
        @type = N'logbased',    --'Proc exec'
        @description = N'', 
        @creation_script = N'', 
        @pre_creation_cmd = N'drop', 
        @schema_option = 0x000000000803509F, 
        @identityrangemanagementoption = N'none', 
        @destination_table = N'Group', 
        @destination_owner = N'dbo', 
        @status = 24, 
        @vertical_partition = N'false', 
        @ins_cmd = N'CALL [dbo].[sp_MSins_dboGroup]', 
        @del_cmd = N'CALL [dbo].[sp_MSdel_dboGroup]', 
        @upd_cmd = N'SCALL [dbo].[sp_MSupd_dboGroup]'



/****************************************************************************************************
 4. Stop distribution
 
    Go to the Subscriber DBMS and STOP distribution agents for this publication
       Subscription --> <PublicationName> --> View Synchronization Status --> Stop

    in Replication Monitor                      in SSMS
          find Publication in My Publishers         Goto Subscriber, Find Subscription
          in "All Subscriptions" tab                Right Click appropriate Subscription
          right click Subscription                  Choose "View Synchronization Status"
          choose "Stop Synchronizing"	              Hit "Stop" button

****************************************************************************************************/

--check on the jobs
exec msdb.dbo.sp_help_job @job_name = 'COLLECTION-ILCentral-Distribution'
exec msdb.dbo.sp_help_job @job_name = 'COLLECTION-ILCentralData-Distribution'
exec msdb.dbo.sp_help_job @job_name = 'COLLECTION-ILCentralDataEnt-Distribution'

--stop the jobs
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentral-Distribution'
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentralData-Distribution'
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentralDataEnt-Distribution'



/****************************************************************************************************
 5. Refresh subscriptions
 
    On the Publisher machine, refresh subscriptions for th publications.

****************************************************************************************************/

exec sp_refreshsubscriptions @publication = 'ILCentral'
exec sp_refreshsubscriptions @publication = 'ILCentralData'
exec sp_refreshsubscriptions @publication = 'ILCentralDataEnt'



/****************************************************************************************************
 6. Refresh snapshot
 
    Run Snapshot agent for Publication (on Publication server)

    in Replication Monitor                      in SSMS
        Under "My Publishers"                       On Publisher  
        Select appropriate Publication              Goto Publication, Right Click Publication
        Select "Agents" tab                         Chose "View Snapshot Agent Status"
        Right Click Snapshot Agent                  Hit "Start" button
        choose "Start Agent"	                

****************************************************************************************************/
  
--stop the agent via SQL Server Agent Jobs
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentral-Snapshot'
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentralData-Snapshot'
exec msdb.dbo.sp_stop_job @job_name = 'COLLECTION-ILCentralDataEnt-Snapshot'



/****************************************************************************************************
 7. Restart Distribution
 
    Restart distribution agents (on Subscriber)
      Local Subscriptions --> <PublicationName> --> View Synchronization Status --> Start
****************************************************************************************************/

  In Replication Monitor, 
    My Publishers 
    Select Appropriate Publication 
    Select 'All Sybsctiptions' Tab 
    Right Click Subscription 
    Start Synchronizing


--start the jobs
exec msdb.dbo.sp_start_job @job_name = 'COLLECTION-ILCentral-Distribution'
exec msdb.dbo.sp_start_job @job_name = 'COLLECTION-ILCentralData-Distribution'
exec msdb.dbo.sp_start_job @job_name = 'COLLECTION-ILCentralDataEnt-Distribution'



