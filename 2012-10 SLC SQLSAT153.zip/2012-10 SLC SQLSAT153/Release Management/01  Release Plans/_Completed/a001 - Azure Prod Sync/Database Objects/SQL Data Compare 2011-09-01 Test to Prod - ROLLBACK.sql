USE [Imagine.Web.Consumer.DB]
GO


DROP TABLE [dbo].[QuestionResponse]

UPDATE [dbo].[DBInfo] SET [ProductVersion]='2011.9.108.0'


-- Update rows in [dbo].[ActivityNode]
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=1998
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2022
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2046
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2067
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2088
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2116
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2129
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2153
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2176
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2201
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2226
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2253
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2267
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2294
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2318
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2342
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2366
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2390
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2408
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2435
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2467
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2494
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2529
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2552
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2570
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2601
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2630
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2661
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2689
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2719
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2743
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2771
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2798
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2826
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2854
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2878
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2896
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2921
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2948
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=2977
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3004
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3030
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3051
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3075
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3107
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3138
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3172
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3197
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>EchoRead</Mode>' WHERE [NodeID]=3615

-- Add rows to [dbo].[SequenceNode]
DELETE FROM [dbo].[SequenceNode] WHERE [NodeID] = 7903
DELETE FROM [dbo].[SequenceNode] WHERE [NodeID] = 7904

-- Add rows to [dbo].[SetActivitySavedDataNode]
DELETE FROM [dbo].[SetActivitySavedDataNode] WHERE [NodeID] = 7903
DELETE FROM [dbo].[SetActivitySavedDataNode] WHERE [NodeID] = 7904

-- Update rows in [dbo].[ActivityNode]
UPDATE [dbo].[ActivityNode] SET [NextNodeID]=363 WHERE [NodeID]=365
UPDATE [dbo].[ActivityNode] SET [NextNodeID]=6992 WHERE [NodeID]=366


