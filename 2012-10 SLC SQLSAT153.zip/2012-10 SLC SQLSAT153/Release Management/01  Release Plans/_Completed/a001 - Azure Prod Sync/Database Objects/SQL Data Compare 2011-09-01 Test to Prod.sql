
PRINT N'Creating [dbo].[QuestionResponse]'
GO
CREATE TABLE [dbo].[QuestionResponse]
(
[QuestionResponseID] [bigint] NOT NULL IDENTITY(1, 1),
[ScoreID] [bigint] NOT NULL,
[QuestionNumber] [smallint] NOT NULL,
[ResponseNumber] [smallint] NOT NULL,
[AttemptNumber] [smallint] NOT NULL,
[InListenMode] [bit] NULL,
[ProductVersion] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
)
GO


-- Update rows in [dbo].[ActivityNode]
UPDATE [dbo].[DBInfo] SET [ProductVersion]='2011.9.190.0'



-- Update rows in [dbo].[ActivityNode]
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=1998
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2022
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2046
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2067
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2088
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2116
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2129
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2153
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2176
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2201
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2226
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2253
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2267
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2294
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2318
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2342
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2366
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2390
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2408
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2435
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2467
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2494
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2529
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2552
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2570
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2601
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2630
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2661
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2689
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2719
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2743
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2771
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2798
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2826
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2854
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2878
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2896
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2921
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2948
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=2977
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3004
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3030
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3051
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3075
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3107
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3138
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3172
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3197
UPDATE [dbo].[ActivityNode] SET [ActivitySpecificData]=N'<Mode>Record</Mode>' WHERE [NodeID]=3615

-- Add rows to [dbo].[SequenceNode]
INSERT INTO [dbo].[SequenceNode] ([NodeID], [NodeGUID], [Skills], [LessonNodeID], [NodeTypeID]) VALUES (7903, 'a2b78eac-5ddf-4dcd-8dfc-2f98b9b712d5', N'', 1, 8)
INSERT INTO [dbo].[SequenceNode] ([NodeID], [NodeGUID], [Skills], [LessonNodeID], [NodeTypeID]) VALUES (7904, 'b9672889-b021-40fe-ba90-2b3cd4361efd', N'', 1, 8)

-- Add rows to [dbo].[SetActivitySavedDataNode]
INSERT INTO [dbo].[SetActivitySavedDataNode] ([NodeID], [ActivityID], [VariableName], [Value], [NextNodeID]) VALUES (7903, 64, N'ThemeSongPlayedBeginLevel', N'True', 363)
INSERT INTO [dbo].[SetActivitySavedDataNode] ([NodeID], [ActivityID], [VariableName], [Value], [NextNodeID]) VALUES (7904, 64, N'ThemeSongPlayedBeginLevel', N'True', 6992)

-- Update rows in [dbo].[ActivityNode]
UPDATE [dbo].[ActivityNode] SET [NextNodeID]=7903 WHERE [NodeID]=365
UPDATE [dbo].[ActivityNode] SET [NextNodeID]=7904 WHERE [NodeID]=366


