USE [ILCentral]
GO

/****** Object:  View [dbo].[CentralInstallation]    Script Date: 09/06/2011 10:01:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


alter view [dbo].[CentralInstallation]
as
	select
			i.Description,
			i.Serial,
			i.PassCode,
			i.Category,
			i.DisplayName,
			i.District,
			i.STSName,
			i.BaseInstallation,
			i.LastPhoneHome,
			i.ExpectedToPhoneHome,
			i.CurrentVersion,
			i.UpdateLevel,
			i.CustomMaxVersion,
			i.PendingUpdate,
			i.PendingUpdateStatus,
			i.SupportComment,
			case 
				when i.LastDataSync is not null then i.LastDataSync
				when i.Seed is null
					then 
					(
						select COALESCE(i.LastDataSync, MAX(d.TimeStamp))
							from ILCentralData.dbo.ILCentralDataDump as d
							where d.SchoolID = i.DataLinkSchoolID
					)  
				else null
			end	as LastDataSync,
			i.UsersLicensed,
			i.LicensesUsed,
			i.LastBackupTime,
			i.LastBackupLocation,
			i.FixedDrives,
			i.LocalIPAddress,
			i.MACAddress,
			i.ComputerName,
			i.SubnetMask,
			i.DefaultGateway,
			i.DHCPEnabled,
			i.DHCPServer,
			i.DNSServer,
			i.DNSSuffix,
			i.RunningAs,
			i.Domain,
			i.ProxyINIhost,
			i.ProxyINIport,
			i.ProxyINIusername,
			i.ProxyINIpassword,
			i.ProxyINIdomain,
			i.ProxyRegServer,
			i.ProxyRegScript,
			case when i.DataLinkSchoolID = '00000000-0000-0000-0000-000000000000'
				then null
				else COALESCE(i.School, i.DataLinkSchoolID)
				end as SchoolID,
			i.RemoteExecName,
			isnull(i.SupportNeedsDB, 0) as SupportNeedsDB,
			i.Seed,
			i.ReportParentInstitutionID,
			rs.Expires,
			case
				when UsersLicensed = 0 or UsersLicensed is null then 
					case
						when ISNULL(LicensesUsed, 0) = 0 then 1 --we want school that have zero licenses, using zero to show 100%
						else null
					end
				else CAST(ISNULL(LicensesUsed, 0) as float) / UsersLicensed
			end as PercentLicensesUsed,
			i.DataSyncASAP
		from ILCentral.dbo.Installation as i
			left outer join ILCentral.dbo.RegistrationStatus as rs
				on rs.Serial = i.Serial
				


GO


