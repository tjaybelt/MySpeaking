INSERT INTO [dbo].[Institution]
           ([InstitutionGUID]
           ,[Name]
           ,[Address]
           ,[City]
           ,[State]
           ,[Zip]
           ,[Country]
           ,[ParentInstitutionID]
           ,[LicenseLimit])
     VALUES
           (NEWID()
           ,'Root'
           ,''
           ,''
           ,''
           ,''
           ,''
           ,NULL
           ,2147483647)
GO

INSERT INTO [dbo].[Institution]
           ([InstitutionGUID]
           ,[Name]
           ,[Address]
           ,[City]
           ,[State]
           ,[Zip]
           ,[Country]
           ,[ParentInstitutionID]
           ,[LicenseLimit])
     VALUES
           (NEWID()
           ,'Consumer'
           ,''
           ,''
           ,''
           ,''
           ,''
           ,(SELECT TOP 1 InstitutionID FROM [dbo].[Institution] WHERE ParentInstitutionID IS NULL)
           ,(SELECT TOP 1 LicenseLimit FROM [dbo].[Institution] WHERE ParentInstitutionID IS NULL))
GO


INSERT INTO [DBInfo]
           ([DbGUID]
           ,[PrimaryKeySeed]
           ,[DbVersion]
           ,[ProductVersion]
           ,[RootInstitutionID]
           ,[SecretKey]
           ,[HwID1]
           ,[HwID2]
           ,[HwID3]
           ,[HwID4])
     VALUES
           (NEWID()
           ,-1
           ,0
           ,'2011.9.216.0'
           ,(SELECT TOP 1 InstitutionID FROM Institution)
           ,0x54314F350ECB6FC9DF81C125F4346D14D96964F2AC838BB207B040F0E47A3B8B
           ,''
           ,''
           ,''
           ,'')
GO

INSERT INTO [User]
           ([UserGUID]
           ,[InstitutionID]
           ,[UserType]
           ,[UserName]
           ,[FirstName]
           ,[LastName]
           ,[DisplayName]
           ,[PhoneNumber]
           ,[Title]
           ,[IsBuiltInAdmin]
           ,[PasswordHash]
           ,[LanguageID]
           ,[PhotoID]
           ,[WindowsAuthentication])
     VALUES
           (NEWID()
           ,(SELECT TOP 1 InstitutionID FROM Institution)
           ,0
           ,'support@imaginelearning.com'
           ,''
           ,''
           ,'Administrator'
           ,''
           ,''
           ,1
           ,0x97FAE03C09D55C27EEAA6640DF9ACE20DD25D1376CA07851A07F1D0A437EF4CD
           ,0
           ,(SELECT TOP 1 PhotoID FROM Photo)
           ,0)
GO


INSERT INTO [dbo].[UserInvitesRemaining]
           ([UserID]
           ,[InvitesRemaining])
     VALUES
           ((SELECT TOP 1 UserID FROM [User] WHERE UserName = 'support@imaginelearning.com')
           ,999)
GO

UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.226.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.229.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.231.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.231.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.232.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.232.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.233.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.234.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.234.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.234.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.235.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.235.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.236.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.237.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.238.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.239.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.240.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.240.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.241.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.242.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.243.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.244.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.245.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.246.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.247.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.248.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.249.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.250.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.251.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.252.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.253.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.254.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.255.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.256.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.257.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.258.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.258.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.259.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.260.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.261.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.262.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.263.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.264.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.265.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.266.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.267.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.268.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.269.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.270.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.271.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.272.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.273.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.273.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.274.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.275.0' 
UPDATE [dbo].[DBInfo] SET [ProductVersion] = '2011.9.280.0' 
