USE ILCentralDataEnt

PRINT N'Adding new [TestInstanceID] column to [dbo].[Student]'

ALTER TABLE [dbo].[Student]
ADD [TestInstanceID] bigint NULL

PRINT N'Creating [dbo].[TestQuestionInstance]'

CREATE TABLE [dbo].[TestQuestionInstance]
(
[TestQuestionInstanceID] [bigint] NOT NULL IDENTITY(1, 1),
[TestSectionInstanceID] [bigint] NOT NULL,
[TestQuestionID] [int] NOT NULL,
[TimeStarted] [datetime2] (2) NULL CONSTRAINT [DF_TestQuestionInstance_TimeStarted] DEFAULT (getdate()),
[TimeCompleted] [datetime2] (2) NULL
) ON [PRIMARY]

PRINT N'Creating primary key [PK_TestQuestionInstance] on [dbo].[TestQuestionInstance]'

ALTER TABLE [dbo].[TestQuestionInstance] ADD CONSTRAINT [PK_TestQuestionInstance] PRIMARY KEY CLUSTERED  ([TestQuestionInstanceID]) ON [PRIMARY]

PRINT N'Creating [dbo].[TestInstance]'

CREATE TABLE [dbo].[TestInstance]
(
[TestInstanceID] [bigint] NOT NULL IDENTITY(1, 1),
[StudentID] [bigint] NOT NULL,
[TestTypeID] [int] NOT NULL,
[LessonNodeID] [smallint] NOT NULL,
[LessonBranchID] [tinyint] NOT NULL,
[TimeStarted] [datetime2] (2) NOT NULL,
[TimeCompleted] [datetime2] (2) NULL
) ON [PRIMARY]

PRINT N'Creating primary key [PK_TestInstance] on [dbo].[TestInstance]'

ALTER TABLE [dbo].[TestInstance] ADD CONSTRAINT [PK_TestInstance] PRIMARY KEY CLUSTERED  ([TestInstanceID]) ON [PRIMARY]

PRINT N'Creating [dbo].[TestOptionInstance]'

CREATE TABLE [dbo].[TestOptionInstance]
(
[TestOptionInstanceID] [bigint] NOT NULL IDENTITY(1, 1),
[TestQuestionInstanceID] [bigint] NOT NULL,
[TestOptionID] [int] NOT NULL,
[IsSelected] [bit] NOT NULL,
[ClickCount] [int] NULL,
[ResponseLatency] [int] NULL
) ON [PRIMARY]

PRINT N'Creating primary key [PK_TestOptionInstance_1] on [dbo].[TestOptionInstance]'

ALTER TABLE [dbo].[TestOptionInstance] ADD CONSTRAINT [PK_TestOptionInstance_1] PRIMARY KEY CLUSTERED  ([TestOptionInstanceID]) ON [PRIMARY]

PRINT N'Creating [dbo].[TestSectionInstance]'

CREATE TABLE [dbo].[TestSectionInstance]
(
[TestSectionInstanceID] [bigint] NOT NULL IDENTITY(1, 1),
[TestInstanceID] [bigint] NOT NULL,
[TestNodeID] [smallint] NOT NULL,
[TestProficiencyDataVersionID] [int] NULL,
[TestProficiencyPredictionResultTypeID] [int] NULL,
[TestProficiencyPredictionData] [varchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TestSectionID] [int] NOT NULL,
[TimeStarted] [datetime2] (2) NULL,
[TimeCompleted] [datetime2] (2) NULL
) ON [PRIMARY]

PRINT N'Creating primary key [PK_TestSectionInstance_1] on [dbo].[TestSectionInstance]'

ALTER TABLE [dbo].[TestSectionInstance] ADD CONSTRAINT [PK_TestSectionInstance_1] PRIMARY KEY CLUSTERED  ([TestSectionInstanceID]) ON [PRIMARY]

PRINT N'Adding foreign keys to [dbo].[Student]'

ALTER TABLE [dbo].[Student] ADD
CONSTRAINT [FK_Student_TestInstance] FOREIGN KEY ([TestInstanceID]) REFERENCES [dbo].[TestInstance] ([TestInstanceID])

PRINT N'Adding foreign keys to [dbo].[TestSectionInstance]'

ALTER TABLE [dbo].[TestSectionInstance] ADD
CONSTRAINT [FK_TestSectionInstance_TestInstance] FOREIGN KEY ([TestInstanceID]) REFERENCES [dbo].[TestInstance] ([TestInstanceID])

PRINT N'Adding foreign keys to [dbo].[TestInstance]'

ALTER TABLE [dbo].[TestInstance] ADD
CONSTRAINT [FK_TestInstance_Student] FOREIGN KEY ([StudentID]) REFERENCES [dbo].[Student] ([StudentID])

PRINT N'Adding foreign keys to [dbo].[TestOptionInstance]'

ALTER TABLE [dbo].[TestOptionInstance] ADD
CONSTRAINT [FK_TestOptionInstance_TestQuestionInstance] FOREIGN KEY ([TestQuestionInstanceID]) REFERENCES [dbo].[TestQuestionInstance] ([TestQuestionInstanceID])

PRINT N'Adding foreign keys to [dbo].[TestQuestionInstance]'

ALTER TABLE [dbo].[TestQuestionInstance] ADD
CONSTRAINT [FK_TestQuestionInstance_TestSectionInstance] FOREIGN KEY ([TestSectionInstanceID]) REFERENCES [dbo].[TestSectionInstance] ([TestSectionInstanceID])

EXEC sp_addextendedproperty N'MS_Description', N'FK Lesson Branch: Lesson Branch when the student started the Test Instance; if Null then Lesson has no Remediation Branches', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'LessonBranchID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Lesson Node: Lesson Node when the student started the Test Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'LessonNodeID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Student', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'StudentID'

EXEC sp_addextendedproperty N'MS_Description', N'PK', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'TestInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Type: Test Type when the student started the Test Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'TestTypeID'

EXEC sp_addextendedproperty N'MS_Description', N'When the student completed the Test Instance; if Null then student is not done', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'TimeCompleted'

EXEC sp_addextendedproperty N'MS_Description', N'When the student started the Test Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestInstance', 'COLUMN', N'TimeStarted'

EXEC sp_addextendedproperty N'MS_Description', N'This is the number of times the student clicked on the Test Option while answering the Test Question', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'ClickCount'

EXEC sp_addextendedproperty N'MS_Description', N'If True then the student selected the Test Option; if False then the student de-selected the Test Option', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'IsSelected'

EXEC sp_addextendedproperty N'MS_Description', N'Milliseconds from when the Test Question was presented until the last click on the Test Option', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'ResponseLatency'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Option', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'TestOptionID'

EXEC sp_addextendedproperty N'MS_Description', N'PK', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'TestOptionInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Question Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestOptionInstance', 'COLUMN', N'TestQuestionInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Question', 'SCHEMA', N'dbo', 'TABLE', N'TestQuestionInstance', 'COLUMN', N'TestQuestionID'

EXEC sp_addextendedproperty N'MS_Description', N'PK', 'SCHEMA', N'dbo', 'TABLE', N'TestQuestionInstance', 'COLUMN', N'TestQuestionInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Section Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestQuestionInstance', 'COLUMN', N'TestSectionInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'When the student finished answering the Test Question; if Null then student did not finish', 'SCHEMA', N'dbo', 'TABLE', N'TestQuestionInstance', 'COLUMN', N'TimeCompleted'

EXEC sp_addextendedproperty N'MS_Description', N'When the question was presented to the student; If interrupted reset the start time', 'SCHEMA', N'dbo', 'TABLE', N'TestQuestionInstance', 'COLUMN', N'TimeStarted'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Instance', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Node', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestNodeID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Proficiency Data Version; if Null then no prediction was made', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestProficiencyDataVersionID'

EXEC sp_addextendedproperty N'MS_Description', N'The data used to calculate the proficiency prediction (in XML format); if Null then no prediction was made', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestProficiencyPredictionData'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Proficiency Prediction Result Type;  If Null then no prediction was made', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestProficiencyPredictionResultTypeID'

EXEC sp_addextendedproperty N'MS_Description', N'FK Test Section; if Null then a Test Section was not presented to the student', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestSectionID'

EXEC sp_addextendedproperty N'MS_Description', N'PK', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TestSectionInstanceID'

EXEC sp_addextendedproperty N'MS_Description', N'When the student completed the Test Section; if Null then student is not finished with the Test Section', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TimeCompleted'

EXEC sp_addextendedproperty N'MS_Description', N'When the student started the Test Section; if Null then a Test Section was not presented to the student', 'SCHEMA', N'dbo', 'TABLE', N'TestSectionInstance', 'COLUMN', N'TimeStarted'
